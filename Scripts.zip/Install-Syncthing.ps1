If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) { Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit }
$title = Split-Path -Leaf $PSCommandPath
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content) { Write-Host -f Green $content; ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -UF '%a %d-%m-%G %X') $title - $content" }
trap { Log "FOUT: $($_.Exception.Message)"; continue }
Log "Installatie gestart"

$SyncThingAdmin = "STAdmin"
$SyncThingAdminPassword = "P@ssw0rd!2025"

$MDTDir = "D:\MDT\DeploymentShare"
$SyncThingDir = 'D:\MDT\Software\SyncThing'
Log "SyncThingDir = $SyncThingDir"
md $SyncThingDir -EA 0

$ConfigDir = Join-Path $SyncThingDir 'Config'
Log "ConfigDir = $ConfigDir"
md $ConfigDir -EA 0

$ServiceName = 'SyncThing'
Log "ServiceName = $ServiceName"

$SyncthingExe = Join-Path $SyncThingDir 'syncthing.exe'
Log "SyncthingExe = $SyncthingExe"

$NssmExe = Join-Path $SyncThingDir 'nssm.exe'
Log "NssmExe = $NssmExe"

$LocalUri = "http://127.0.0.1:8384"
Log "LocalUri = $LocalUri"

Log "Nieuwste SyncThing versie downloaden"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$json = (iwr https://api.github.com/repos/syncthing/syncthing/releases -UseBasicParsing).Content | ConvertFrom-Json
$WebVersion = (($json | ? name -match v2)[0].name).substring(1)
$LocalVersion = (gi $PSScriptRoot\Syncthing.exe).VersionInfo.FileVersion
If ($WebVersion -gt $LocalVersion) {
    Start-BitsTransfer (($json | ? name -match v2)[0].assets | ? name -match windows-amd).browser_download_url $PSScriptRoot\Syncthing.zip
    Expand-Archive $PSScriptRoot\Syncthing.zip $PSScriptRoot -Force
    del $PSScriptRoot\Syncthing.zip
    mv (dir $PSScriptRoot -Recurse -Filter syncthing.exe | Select -First 1).FullName $SyncthingExe -Force
    del -Recurse -Force (dir $PSScriptRoot -Directory | ? { $_.Name -like "syncthing*" }).FullName
}
Log "Geen nieuwere versie van SyncThing beschikbaar"

Log "NSSM downloaden (the non-sucking service manager)"
iwr "https://nssm.cc/ci/nssm-2.24-103-gdee49fc.zip" -OutFile $PSScriptRoot\nssm.zip
Expand-Archive $PSScriptRoot\nssm.zip $PSScriptRoot -Force
del $PSScriptRoot\nssm.zip
mv (dir $PSScriptRoot -Recurse -Filter nssm.exe | ? FullName -match win64).FullName $NssmExe -Force
del -Recurse -Force (dir $PSScriptRoot -Directory | ? { $_.Name -like "nssm*" }).FullName

$AllowedChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#[]{}()-_=+"
$Password = -join (1..120 | % { $AllowedChars[(Get-Random -Maximum 120)] })
$SecurePassword = ConvertTo-SecureString $Password -A -F
If (Get-LocalUser -Name $ServiceName -EA 0) {
    Log "$ServiceName bestaat al, wachtwoord bijwerken..."
    Set-LocalUser $ServiceName -Password $SecurePassword
}
else {
    Log "SyncThing gebruikersaccount aanmaken"
    New-LocalUser -AccountNeverExpires -Description "Gebruiker voor replicatie met SyncThing" -Name $ServiceName -Password $SecurePassword -PasswordNeverExpires -UserMayNotChangePassword | Add-LocalGroupMember -Group Users
}

Log "Batch bestanden aanmaken..."
$batchContent = @{
    'install-service.bat' = @"
@echo off
`"$NssmExe`" install $ServiceName `"$SyncthingExe`" --no-console --no-browser --home=`"$ConfigDir`"
`"$NssmExe`" set $ServiceName Start SERVICE_DELAYED_AUTO_START
`"$NssmExe`" set $ServiceName Description "Syncthing service voor bestandssynchronisatie"
`"$NssmExe`" set $ServiceName ObjectName .\$ServiceName $Password
`"$NssmExe`" set $ServiceName AppStopMethodConsole 1
`"$NssmExe`" set $ServiceName AppStopMethodWindow 1
`"$NssmExe`" set $ServiceName AppStopMethodThreads 1
`"$NssmExe`" set $ServiceName AppExit Default Restart
`"$NssmExe`" set $ServiceName AppExit 0 Exit
`"$NssmExe`" start $ServiceName
timeout 5
"@

    'start-service.bat'   = @"
@echo off
`"$NssmExe`" start $ServiceName
timeout 5
"@

    'stop-service.bat'    = @"
@echo off
`"$NssmExe`" stop $ServiceName
timeout 5
"@

    'edit-service.bat'    = @"
@echo off
`"$NssmExe`" edit $ServiceName
"@

    'status-service.bat'  = @"
@echo off
`"$NssmExe`" status $ServiceName
timeout 10
"@

    'remove-service.bat'  = @"
@echo off
`"$NssmExe`" stop $ServiceName
`"$NssmExe`" remove $ServiceName confirm
timeout 5
"@

    'restart-service.bat' = @"
@echo off
`"$NssmExe`" stop $ServiceName
timeout 5
`"$NssmExe`" start $ServiceName
timeout 5
"@
}

foreach ($file in $batchContent.Keys) {
    $path = Join-Path $SyncThingDir $file
    $batchContent[$file] | Out-File -FilePath $path -Encoding ASCII -Force
}

Log "Snelkoppeling naar GUI op openbare bureaublad aanmaken..."
$content = @"
[InternetShortcut]
URL=$LocalUri
"@
sc "$ENV:PUBLIC\Desktop\SyncThing GUI.url" $content -Encoding ASCII
sc "$SyncThingDir\SyncThing GUI.url" $content -Encoding ASCII

Log "Installatie batch starten..."
Start (Join-Path $SyncThingDir 'install-service.bat') -Wait

$configPath = Join-Path $ConfigDir 'config.xml'
$timeout = 30
Log "Wachten op config.xml"
$sw = [Diagnostics.Stopwatch]::StartNew()
while (!(Test-Path $configPath) -and $sw.Elapsed.TotalSeconds -lt $timeout) { Sleep 1 }
if (!(Test-Path $configPath)) {
    Log "config.xml niet gevonden na $timeout seconden, installatie mislukt. Afsluiten."
    exit 1
}

[xml]$config = gc $configPath
$apiKey = $config.configuration.gui.apikey
$deviceID = $config.configuration.device.id
@{ ApiKey = $apiKey; DeviceID = $deviceID } | ConvertTo-Json | sc "$MDTDir\$ENV:COMPUTERNAME.json" -Force -Encoding UTF8
$api = @{Method = 'Put'; ContentType = 'application/json'; Headers = @{ 'X-API-Key' = $apiKey } }

Log "DeploymentShare map in Syncthing aanmaken..."
@('Backup', 'Boot', 'Control/Bootstrap.ini', 'Logs', 'Audit.log', "*.json") | Out-File "$MDTDir\.stignore" -Encoding UTF8 -Force
$folderBody = @{
    id           = 'DeploymentShare'
    label        = 'DeploymentShare'
    path         = $MDTDir
    type         = 'sendreceive'
    ignorePerms  = $true
    ignoreDelete = $false
} | ConvertTo-Json -Depth 5
irm "$LocalUri/rest/config/folders/DeploymentShare" -Body $folderBody @api

Log "Opties instellen..."
$autoAcceptBody = @{
    autoAcceptFolders                  = $true
    autoAcceptDevices                  = $true
    autoAcceptFoldersWithRemoteDevices = $true
    urAccepted                         = -1
    urSeen                             = 3
} | ConvertTo-Json
irm "$LocalUri/rest/config/options" -Body $autoAcceptBody @api

Log "GUI gebruikersnaam en wachtwoord instellen..."
$guiConfig = @{
    address  = "0.0.0.0:8384"
    user     = $SyncThingAdmin
    password = $SyncThingAdminPassword
    apikey   = "$apiKey"
} | ConvertTo-Json
irm "$LocalUri/rest/config/gui" -Body $guiConfig @api

Log "Firewall regels voor beheer (Syncthing Management en RDP)"
New-NetFirewallRule -DisplayName "Syncthing Management (TCP 8384)" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 8384 -Program $SyncthingExe -Profile Any -Enabled True | Out-Null

Log "Firewall regel voor synchronisatie Beheer EN Engineers"
New-NetFirewallRule -DisplayName "Syncthing Sync (TCP 22000)" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 22000 -Program $SyncthingExe -Profile Any -Enabled True | Out-Null

Log "Syncthing service is geinstalleerd en geconfigureerd."

Exit 0