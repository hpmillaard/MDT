$RootPath = "D:\MDT"
$Deploymentshare = "$RootPath\DeploymentShare"
$Source = "$RootPath\Apps"
$Import = $true

If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}

#######
# The following rules determine the logic in this script
#######
Import-Module "$ENV:ProgramFiles\Microsoft Deployment Toolkit\bin\MicrosoftDeploymentToolkit.psd1"
New-PSDrive -Name "DS001" -PSProvider MDTProvider -Root "$DeploymentShare"
Function ImportApp{
	param([Parameter(Mandatory=$true)][string]$Command,[Parameter(Mandatory=$true)][string]$Name,[Parameter(Mandatory=$False)]$Reboot)
	$location = Get-Location
	Set-Location "DS001:\Applications"
	If (Test-Path $Name){If ($Name -notmatch "VDA" -and $Name -notmatch "XenConvert"){Remove-Item $Name -Recurse -Force}}
	If ($Import) {
		Import-MDTApplication -Name $Name -ShortName $Name -enable "True" -CommandLine $Command -WorkingDirectory ".\Applications\$Name" -ApplicationSourcePath (Join-Path $Source $Name) -DestinationFolder $Name
	} ELSE {
		If ($Command -Match " ") {$CMD = $Command.Split(" "); $C = $CMD[1]; $Command = $CMD[0]+" """+(Join-Path $Source $Name\$C)+""""} ELSE {$Command = """"+(Join-Path $Source $Name\$Command)+""""}
		Import-MDTApplication -Name $Name -ShortName $Name -enable "True" -CommandLine $Command -NoSource
	}
	If ($Reboot){Set-ItemProperty -path "DS001:\Applications\$Name" -Name Reboot -Value True}
	While (Test-Path -Path $DeploymentShare\Control\Applications.LOCK){Start-Sleep -Milliseconds 10}
	Set-Location $location
}

#######
# Add applications
# ImportApp("commandline") ("App name is equal to the folder name in the $Source share you set above") [("True for reboot")]
# If you add an empty text file named ExcludeMDT.txt to the application folder, than this app won't be imported
# If you add an empty text file named reboot.txt to the application folder, than MDT will reboot the computer after installation of this app and will continue installation afterwards
#######
del "DS001:\Applications\*"
ForEach ($Folder in Get-Childitem -Path $Source) {
	If (!(Test-Path ($Folder.FullName + "\ExcludeMDT.txt"))) {
		If (Test-Path ($Folder.FullName + "\install.bat")) {
			If (Test-Path ($Folder.FullName + "\reboot.txt")) {
				ImportApp("install.bat") ($Folder.Name) ("True")
			} Else {
				ImportApp("install.bat") ($Folder.Name)
			}
		}
		If (Test-Path ($Folder.FullName + "\install.vbs")) {
			If (Test-Path ($Folder.FullName + "\reboot.txt")) {
				ImportApp("wscript install.vbs") ($Folder.Name) ("True")
			} Else {
				ImportApp("wscript install.vbs") ($Folder.Name)
			}
		}
	}
}

#######
# You can sequence the application install order normally in the CustomSettings.ini file.
# The following rules make it possible to just call 1 app from the CustomSettings.ini and still use an install sequence
# If you want to create a specific installation sequence to an App (VDA in this example), you can use the following lines (please uncomment the next lines by removing #):
#######
# $Order = @()
# $Order = $Order + (Get-ItemProperty -Path "DS001:\Applications\AppName1").Guid
# $Order = $Order + (Get-ItemProperty -Path "DS001:\Applications\AppName2").Guid
# Set-ItemProperty -path "DS001:\Applications\VDA" -Name Dependency -Value $Order
