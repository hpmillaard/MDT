$host.ui.RawUI.WindowTitle = "Install and Configure DHCP Server"

Write-Host "Run as Admin" -f green
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Start-Process powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

Write-Host "Getting current network configuration..." -f green
$adapter = Get-NetIPConfiguration | Where-Object { $_.IPv4DefaultGateway -ne $null -and $_.NetAdapter.Status -eq "Up" } | Select-Object -First 1

if (!$adapter) {
    Write-Host "ERROR: No active network adapter with gateway found!" -f red
    pause
    exit
}

$ipAddress = $adapter.IPv4Address.IPAddress
$subnetMask = $adapter.IPv4Address.PrefixLength
$gateway = $adapter.IPv4DefaultGateway.NextHop
$dnsServers = $adapter.DNSServer.ServerAddresses | Where-Object { $_ -match '^\d+\.\d+\.\d+\.\d+$' }

Write-Host "Current Configuration:" -f cyan
Write-Host "  IP Address: $ipAddress/$subnetMask" -f white
Write-Host "  Gateway: $gateway" -f white
Write-Host "  DNS Servers: $($dnsServers -join ', ')" -f white

# Calculate subnet mask from prefix length
$maskBits = ('1' * $subnetMask) + ('0' * (32 - $subnetMask))
$maskOctets = @()
for ($i = 0; $i -lt 4; $i++) {
    $maskOctets += [Convert]::ToInt32($maskBits.Substring($i * 8, 8), 2)
}
$subnetMaskStr = $maskOctets -join '.'

# Calculate network address
$ipOctets = $ipAddress.Split('.')
$networkOctets = @()
for ($i = 0; $i -lt 4; $i++) {
    $networkOctets += [int]$ipOctets[$i] -band [int]$maskOctets[$i]
}
$networkStr = $networkOctets -join '.'

$scopeStart = "$($networkOctets[0]).$($networkOctets[1]).$($networkOctets[2]).100"
$scopeEnd = "$($networkOctets[0]).$($networkOctets[1]).$($networkOctets[2]).200"
$scopeName = "Scope_$networkStr"

Write-Host "`nDHCP Scope Configuration:" -f cyan
Write-Host "  Network: $networkStr/$subnetMask" -f white
Write-Host "  Subnet Mask: $subnetMaskStr" -f white
Write-Host "  Scope Range: $scopeStart - $scopeEnd" -f white
Write-Host "  Scope Name: $scopeName" -f white

$confirm = Read-Host "`nContinue with DHCP installation? (Y/N)"
if ($confirm -ne 'Y' -and $confirm -ne 'y') {
    Write-Host "Installation cancelled." -f yellow
    pause
    exit
}

Write-Host "`nInstalling DHCP Server feature..." -f green
$result = Install-WindowsFeature -Name DHCP -IncludeManagementTools

if (!$result.Success) {
    Write-Host "ERROR: DHCP installation failed!" -f red
    pause
    exit
}

Write-Host "Configuring DHCP Server..." -f green

# Add DHCP Server to Active Directory (if domain joined)
$computerSystem = Get-WmiObject -Class Win32_ComputerSystem
if ($computerSystem.PartOfDomain) {
    Write-Host "Adding DHCP server to Active Directory..." -f yellow
    try {
        Add-DhcpServerInDC -DnsName $env:COMPUTERNAME -IPAddress $ipAddress -EA Stop
        Write-Host "DHCP server successfully added to Active Directory" -f green
    } catch {
        Write-Host "Warning: Could not add to Active Directory: $_" -f yellow
    }
} else {
    Write-Host "Server is not domain joined, skipping AD registration" -f yellow
}

Write-Host "Creating DHCP scope..." -f green
Add-DhcpServerv4Scope -Name $scopeName -StartRange $scopeStart -EndRange $scopeEnd -SubnetMask $subnetMaskStr -State Active -LeaseDuration 0.01:00:00

Write-Host "Configuring scope options..." -f green
Set-DhcpServerv4OptionValue -ScopeId $networkStr -Router $gateway
if ($dnsServers) {
    Set-DhcpServerv4OptionValue -ScopeId $networkStr -DnsServer $dnsServers
}

Write-Host "Completing DHCP server configuration..." -f green
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\ServerManager\Roles\12" -Name "ConfigurationState" -Value 2 -EA 0

Write-Host "Binding DHCP to network interface..." -f green
$interfaceAlias = $adapter.InterfaceAlias
Set-DhcpServerv4Binding -InterfaceAlias $interfaceAlias -BindingState $true
Write-Host "DHCP bound to interface: $interfaceAlias" -f green

# Configure WDS if installed
if ((Get-WindowsFeature WDS).InstallState -eq "Installed") {
    Write-Host "WDS detected - Configuring DHCP Option 60..." -f green
    try {
        $null = WDSutil /Set-Server /UseDhcpPorts:No /DhcpOption60:Yes
        Write-Host "WDS configured to work with DHCP on same server" -f green
    } catch {
        Write-Host "Warning: Could not configure WDS DHCP option: $_" -f yellow
    }
} else {
    Write-Host "WDS not installed, skipping WDS configuration" -f yellow
}

Write-Host "Restarting DHCP service..." -f green
Restart-Service DHCPServer

Write-Host "`nDHCP Server installation and configuration completed successfully!" -f green
Write-Host "`nScope Information:" -f cyan
Get-DhcpServerv4Scope | Format-Table -AutoSize

pause