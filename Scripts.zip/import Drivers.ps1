$RootPath = "D:\MDT"
$Deploymentshare = "$RootPath\DeploymentShare"
$DriversFolder = "$RootPath\Drivers"

If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) { Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit }
Import-Module "$ENV:ProgramFiles\Microsoft Deployment Toolkit\bin\MicrosoftDeploymentToolkit.psd1"
New-PSDrive -Name "DS001" -PSProvider MDTProvider -Root "$DeploymentShare"

gci $DriversFolder -Directory -Depth 0 | ForEach {
	Write-host $_
	MD "DS001:\Out-of-Box Drivers\$_"
	import-mdtdriver -path "DS001:\Out-of-Box Drivers\$_" -SourcePath "$DriversFolder\$_" -Verbose
}
pause