param ([string[]]$ImportOS)
$ValidOS = "11", "11-Insider", "2012", "2016", "2019", "2022", "2025", "2025-Insider"
if ($ImportOS -is [string]) {$ImportOS = $ImportOS -split ","} elseif ($ImportOS.Count -eq 1 -and $ImportOS[0] -match ',') {$ImportOS = $ImportOS[0] -split ","}
if (!$ImportOS) {$ImportOS = @($ValidOS | % { [PSCustomObject]@{Version = $_} } | ogv -Title "Select OS versions to import in MDT" -OutputMode Multiple).Version}
foreach ($v in $ImportOS) {if ($v -notin $ValidOS) { throw "Invalid OS specified: $v" }}
Write-Host "Count: $($ImportOS.Count)" -F Yellow
Write-Host "Raw input:" -F Cyan
$ImportOS | % { Write-Host "- $_" }

$W2012URL = "http://download.microsoft.com/download/6/2/A/62A76ABB-9990-4EFC-A4FE-C7D698DAEB96/9600.17050.WINBLUE_REFRESH.140317-1640_X64FRE_SERVER_EVAL_EN-US-IR3_SSS_X64FREE_EN-US_DV9.ISO"
$W2016URL = "https://software-download.microsoft.com/download/pr/Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh.ISO"
$W2019URL = "https://software-download.microsoft.com/download/pr/17763.737.190906-2324.rs5_release_svc_refresh_SERVER_EVAL_x64FRE_en-us_1.iso"
$W2022URL = "https://software-download.microsoft.com/download/sg/20348.169.210806-2348.fe_release_svc_refresh_SERVER_EVAL_x64FRE_en-us.iso"
$W2025URL = "https://go.microsoft.com/fwlink/?linkid=2293312&clcid=0x409&culture=en-us&country=us"

$RootPath = "D:\MDT"
$Deploymentshare = "$RootPath\DeploymentShare"
$ISOFolder = "$RootPath\ISOs"

################################################################################################################################
$host.ui.RawUI.WindowTitle = $PSCommandPath
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) { Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit }
Import-Module "$ENV:ProgramFiles\Microsoft Deployment Toolkit\bin\MicrosoftDeploymentToolkit.psd1"
$null = New-PSDrive -Name "DS001" -PSProvider MDTProvider -Root "$Deploymentshare"
################################################################################################################################
Function MountISO($ISOPath) {
	Write-Host "Mounting $ISO" -F Green
	$before = (Get-Volume).DriveLetter
	$null = Mount-DiskImage $ISO
	$after = (Get-Volume).DriveLetter
	$script:D = $after | Where { $before -notcontains $_ }
	While (!(Test-Path $D':\Sources\install.wim')) { Sleep 1 }
	Write-Host "Install.wim found, starting import" -F Green
}
################################################################################################################################
Function DisMountISO($ISOPath) {
	$null = DisMount-DiskImage $ISOPath
	Write-Host "Dismounted $ISO" -F Green
}
################################################################################################################################
Function Folder($Ver){
	If (!(Test-Path "$ISOFolder\W$Ver")) {$null = md "$ISOFolder\W$Ver"}
	rd "DS001:\Operating Systems\$Ver" -Fo -R -EA 0
	$null = md "DS001:\Operating Systems\$Ver"
	rd "DS001:\Task Sequences\$Ver" -Fo -R -EA 0
	$null = md "DS001:\Task Sequences\$Ver"
	cd "DS001:\Operating Systems\$Ver"
}
################################################################################################################################
# Windows Clients
################################################################################################################################
Function Client($Ver, $Langs = @("EN-US", "NL-NL")) {
	Folder W$Ver
	$version = "Windows " + ($Ver -replace "-Insider")
	foreach ($Lang in $Langs) {
		$ISO = (gi filesystem::$ISOFolder\W$Ver\*$Lang*.ISO).fullname
		If (!($ISO)) { Write-host "$ISO Not found, starting download" -F Yellow; start powershell "$ISOFolder\Download Latest $Ver.ps1" -Wait; $ISO = (gi filesystem::$ISOFolder\W$Ver\*$Lang*.ISO).fullname }
		MountISO($ISO)
		Import-MDTOperatingSystem -Path "DS001:\Operating Systems\W$Ver" -SourcePath $D':\' -DestinationFolder "W$Ver $Lang"
		ren "$version Enterprise in *$Lang*" "W$Ver $Lang Enterprise"
		ren "$version Enterprise multi-session in *$Lang*" "W$Ver $Lang Enterprise multi-session"
		ren "$version Pro in *$Lang*" "W$Ver $Lang Pro"
		del "* in *$Lang*"
		Write-Host "Other Versions removed, start Task Sequence Import" -F Green
		Import-MDTTaskSequence -Path "DS001:\Task Sequences\W$Ver" -Name "W$Ver $Lang Enterprise" -Template "Client.xml" -ID "W$Ver-$Lang-ENT" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W$Ver\W$Ver $Lang Enterprise"
		Import-MDTTaskSequence -Path "DS001:\Task Sequences\W$Ver" -Name "W$Ver $Lang Enterprise multi-session" -Template "Client.xml" -ID "W$Ver-$Lang-ENTMS" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W$Ver\W$Ver $Lang Enterprise multi-session"
		Import-MDTTaskSequence -Path "DS001:\Task Sequences\W$Ver" -Name "W$Ver $Lang Pro" -Template "Client.xml" -ID "W$Ver-$Lang-PRO" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W$Ver\W$Ver $Lang Pro"
		Write-Host "Task Sequences Imported" -F Green
		DisMountISO($ISO)
	}
}
################################################################################################################################

################################################################################################################################
# Windows Servers
################################################################################################################################
Function Server($Ver) {
	Folder W$Ver
	$ISO = (gi filesystem::$ISOFolder\W$Ver\*.ISO | Select -First 1).fullname
	If (!($ISO)) { Write-host "$ISO Not found, starting download" -F Yellow; If ($Ver -match "Insider") { start powershell "$ISOFolder\Download Latest W2025.ps1" -wait; $ISO = (gi filesystem::$ISOFolder\W$Ver\*.ISO | Select -First 1).fullname } Else { Start-BitsTransfer W$Ver`URL "$ISOFolder\W$Ver\$Ver.iso" }}
	MountISO($ISO)
	Import-MDTOperatingSystem -Path "DS001:\Operating Systems\W$Ver" -SourcePath $D':\' -DestinationFolder "W$Ver"
	$null = ren "*SERVERDATACENTER in *" "Windows Server $Ver DataCenter"
	$null = ren "*SERVERDATACENTERCORE in *" "Windows Server $Ver DataCenterCore"
	$null = ren "*SERVERSTANDARD in *" "Windows Server $Ver Standard"
	$null = ren "*SERVERSTANDARDCORE in *" "Windows Server $Ver StandardCore"
	$null = ren "*Datacenter (Desktop Experience) in *" "Windows Server $Ver DataCenter"
	$null = ren "*Datacenter in *" "Windows Server $Ver DataCenterCore"
	$null = ren "*Standard (Desktop Experience) in *" "Windows Server $Ver Standard"
	$null = ren "*Standard in *" "Windows Server $Ver StandardCore"
	del "*Azure*"
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W$Ver" -Name "Windows Server $Ver DataCenter" -Template "Server.xml" -ID "W$Ver`DC" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W$Ver\Windows Server $Ver DataCenter"
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W$Ver" -Name "Windows Server $Ver DataCenterCore" -Template "Server.xml" -ID "W$ver`DCCORE" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W$Ver\Windows Server $Ver DataCenterCore"
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W$Ver" -Name "Windows Server $Ver Standard" -Template "Server.xml" -ID "W$Ver`STD" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W$Ver\Windows Server $Ver Standard"
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W$Ver" -Name "Windows Server $Ver StandardCore" -Template "Server.xml" -ID "W$Ver`STDCORE" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W$Ver\Windows Server $Ver StandardCore"
	DisMountISO($ISO)
}
################################################################################################################################
foreach ($ver in $ImportOS) {
	Write-Host "Processing $ver..." -F Magenta
    switch ($ver) {
        "11" 		   { Client "11" }
        "11-Insider"   { Client "11-Insider" }
        "2012" 		   { Server "2012" }
        "2016" 		   { Server "2016" }
        "2019" 		   { Server "2019" }
        "2022" 		   { Server "2022" }
        "2025" 		   { Server "2025" }
        "2025-Insider" { Server "2025-Insider" }
		default 	   { Write-Host "Unknown OS version: $ver" -F Red }
    }
}

Write-Host "Removing unneeded files and folders" -F Green
dir "$Deploymentshare\Operating Systems\" -R -File | ? { $_.Name -notlike "install.wim" } | del -Fo -R
do {
    $empty = dir "$DeploymentShare\Operating Systems" -R -Directory | ? { $_.GetFiles().Count -eq 0 -and $_.GetDirectories().Count -eq 0 }
    $empty | del -Fo
} while ($empty.Count -gt 0)
