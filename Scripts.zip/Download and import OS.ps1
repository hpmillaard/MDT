param ([string[]]$ImportOS)
$host.ui.RawUI.WindowTitle = $PSCommandPath
################################################################################################################################
If ($PSVersionTable.PSVersion.Major -ge 7) {
	Write-Host "Force Windows PowerShell 5.1 (MDT doesn't work with PowerShell 7)" -f green
    $argString = ""
    if ($ImportOS) { $argString = "-ImportOS '" + ($ImportOS -join "','") + "'" }
    Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" $argString" -Verb RunAs
    exit
}
################################################################################################################################
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) { 
	Write-Host "Run as Admin" -f green
    $argString = ""
    if ($ImportOS) { $argString = "-ImportOS '" + ($ImportOS -join "','") + "'" }
    Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" $argString" -Verb RunAs
    exit 
}
################################################################################################################################
$ValidOS = "11", "11-Insider", "2012", "2016", "2019", "2022", "2025", "2025-Insider"
if ($ImportOS -is [string]) {$ImportOS = $ImportOS -split ","} elseif ($ImportOS.Count -eq 1 -and $ImportOS[0] -match ',') {$ImportOS = $ImportOS[0] -split ","}
if (!$ImportOS) {$ImportOS = @($ValidOS | % { [PSCustomObject]@{Version = $_} } | ogv -Title "Select OS versions to import in MDT" -OutputMode Multiple).Version}
foreach ($v in $ImportOS) {if ($v -notin $ValidOS) { throw "Invalid OS specified: $v" }}
$ImportOS | % { Write-Host "- $_" }

$W2012URL = "http://download.microsoft.com/download/6/2/A/62A76ABB-9990-4EFC-A4FE-C7D698DAEB96/9600.17050.WINBLUE_REFRESH.140317-1640_X64FRE_SERVER_EVAL_EN-US-IR3_SSS_X64FREE_EN-US_DV9.ISO"
$W2016URL = "https://software-download.microsoft.com/download/pr/Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh.ISO"
$W2019URL = "https://software-download.microsoft.com/download/pr/17763.737.190906-2324.rs5_release_svc_refresh_SERVER_EVAL_x64FRE_en-us_1.iso"
$W2022URL = "https://software-download.microsoft.com/download/sg/20348.169.210806-2348.fe_release_svc_refresh_SERVER_EVAL_x64FRE_en-us.iso"
$W2025URL = "https://go.microsoft.com/fwlink/?linkid=2293312&clcid=0x409&culture=en-us&country=us"

$RootPath = "D:\MDT"
$Deploymentshare = "$RootPath\DeploymentShare"
$ISOFolder = "$RootPath\ISOs"
$KMSKeys = $True # Set to $False to skip setting KMS keys in Task Sequences

# Configuration of editions to keep (exact names after rename)
# Client editions: Pro, Pro N, Pro Education, Pro Education N, Pro for Workstations, Pro N for Workstations, Pro Single Language,
#                  Enterprise, Enterprise N, Enterprise multi-session, Education, Education N,
#                  SE, SE N, IoT Enterprise, IoT Enterprise Subscription,
#                  Home, Home N, Home Single Language
$ClientEditionsToKeep = @("IoT Enterprise")

# Server editions: DataCenter, DataCenterCore, Standard, StandardCore
$ServerEditionsToKeep = @("Standard")

################################################################################################################################
Import-Module "$ENV:ProgramFiles\Microsoft Deployment Toolkit\bin\MicrosoftDeploymentToolkit.psd1"
$null = New-PSDrive -Name "DS001" -PSProvider MDTProvider -Root "$Deploymentshare"
################################################################################################################################
Function MountISO($ISOPath) {
	Write-Host "Mounting $ISO" -F Green
	$before = (Get-Volume).DriveLetter
	$null = Mount-DiskImage $ISO
	$after = (Get-Volume).DriveLetter
	$script:D = $after | Where { $before -notcontains $_ }
	While (!(Test-Path $D':\Sources\install.wim')) { Sleep 1 }
	Write-Host "Install.wim found, starting import" -F Green
}
################################################################################################################################
Function DisMountISO($ISOPath) {
	$null = DisMount-DiskImage $ISOPath
	Write-Host "Dismounted $ISO" -F Green
}
################################################################################################################################
Function Folder($Version){
	If (!([System.IO.Directory]::Exists("$ISOFolder\$Version"))) {$null = md "$ISOFolder\$Version"}
	rd "DS001:\Operating Systems\$Version" -Fo -R -EA 0
	$null = md "DS001:\Operating Systems\$Version"
	rd "DS001:\Task Sequences\$Version" -Fo -R -EA 0
	$null = md "DS001:\Task Sequences\$Version"
	cd "DS001:\Operating Systems\$Version"
}
################################################################################################################################
# Windows Clients
################################################################################################################################
Function Client($Ver, $Langs = @("EN-US","NL-NL")) {
	Folder W$Ver
	$version = "Windows " + ($Ver -replace "-Insider")
	foreach ($Lang in $Langs) {
		rd "$Deploymentshare\Operating Systems\$Version $Lang" -Fo -R -EA 0
		rd "$Deploymentshare\Control\W$Ver-$Lang-*" -Fo -R -EA 0
		$ISO = (gi filesystem::$ISOFolder\W$Ver\*$Lang*.ISO).fullname
		If (!$ISO -and [System.IO.File]::Exists("$ISOFolder\W$Ver\Download Latest W$Ver.ps1")){
			Write-host "$ISO Not found, starting download" -F Yellow
			start powershell "$ISOFolder\W$Ver\Download Latest W$Ver.ps1" -Wait
			$ISO = (gi filesystem::$ISOFolder\W$Ver\*$Lang*.ISO).fullname
		}
		MountISO($ISO)
		Import-MDTOperatingSystem -Path "DS001:\Operating Systems\W$Ver" -SourcePath $D':\' -DestinationFolder "W$Ver $Lang"
		DisMountISO($ISO)
		dir "*$Lang*" | % { if ($_.Name -match "^$version (.+?) in W$Ver $Lang install\.wim$") { ren $_.Name -NewName ("W{0} {1} {2}" -f $Ver, $Lang, $Matches[1]) } }
		dir "W$Ver $Lang*" | % {if (($_.Name -replace "^W$Ver $Lang ", "") -notin $ClientEditionsToKeep) {Remove-Item $_.Name -Force -EA 0}}
		foreach ($os in dir "W$Ver $Lang*") {
			$edition = ($os.Name -replace "^W$Ver $Lang ", "")
			$editionId = ($edition -replace '[^A-Za-z0-9\-]', '-') -replace '-{2,}', '-'
			$editionId = $editionId.Trim('-')
			if ($editionId.Length -gt 40) { $editionId = $editionId.Substring(0, 40) }
			$tsFullId = "W$Ver-$Lang-$editionId"
			rd "$Deploymentshare\Control\$tsFullId" -Fo -R -EA 0
			Import-MDTTaskSequence -Path "DS001:\Task Sequences\W$Ver" -Name $os.Name -Template "Client.xml" -ID $tsFullId -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W$Ver\$($os.Name)"
		}
	}
}
################################################################################################################################

################################################################################################################################
# Windows Servers
################################################################################################################################
Function Server($Ver) {
	Folder W$Ver
	rd "$Deploymentshare\Operating Systems\$Version" -Fo -R -EA 0
	rd "$Deploymentshare\Control\W$Ver*" -Fo -R -EA 0
	$ISO = (gi filesystem::$ISOFolder\W$Ver\*.ISO | Select -First 1).fullname
	If (!$ISO) { Write-host "$ISO Not found, starting download" -F Yellow; If (W$Ver`URL) { Start-BitsTransfer W$Ver`URL "$ISOFolder\W$Ver\$Ver.iso" } Else { start powershell "$ISOFolder\W$Ver\Download Latest W$Ver.ps1" -wait; $ISO = (gi filesystem::$ISOFolder\W$Ver\*.ISO | Select -First 1).fullname } }
	MountISO($ISO)
	Import-MDTOperatingSystem -Path "DS001:\Operating Systems\W$Ver" -SourcePath $D':\' -DestinationFolder "W$Ver"
	DisMountISO($ISO)
	$null = ren "*SERVERDATACENTER in *" "Windows Server $Ver DataCenter" -EA 0
	$null = ren "*SERVERDATACENTERCORE in *" "Windows Server $Ver DataCenterCore" -EA 0
	$null = ren "*SERVERSTANDARD in *" "Windows Server $Ver Standard" -EA 0
	$null = ren "*SERVERSTANDARDCORE in *" "Windows Server $Ver StandardCore" -EA 0
	$null = ren "*Datacenter (Desktop Experience) in *" "Windows Server $Ver DataCenter" -EA 0
	$null = ren "*Datacenter in *" "Windows Server $Ver DataCenterCore" -EA 0
	$null = ren "*Standard (Desktop Experience) in *" "Windows Server $Ver Standard" -EA 0
	$null = ren "*Standard in *" "Windows Server $Ver StandardCore" -EA 0
	$null = del "*Azure*" -EA 0
	dir "Windows Server $Ver*" | % {if (($_.Name -replace "^Windows Server $Ver ", "") -notin $ServerEditionsToKeep) {Remove-Item $_.Name -Force -EA 0}}
	foreach ($os in dir "Windows Server $Ver*") {
		$edition = ($os.Name -replace "^Windows Server $Ver ", "")
		$editionId = ($edition -replace '[^A-Za-z0-9\-]', '-') -replace '-{2,}', '-'
		$editionId = $editionId.Trim('-')
		if ($editionId.Length -gt 40) { $editionId = $editionId.Substring(0, 40) }
		$tsFullId = "W$Ver-$editionId"
		rd "$Deploymentshare\Control\$tsFullId" -Fo -R -EA 0
		Import-MDTTaskSequence -Path "DS001:\Task Sequences\W$Ver" -Name $os.Name -Template "Server.xml" -ID $tsFullId -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W$Ver\$($os.Name)"
	}
}
################################################################################################################################
foreach ($ver in $ImportOS) {
    Write-Host "Processing $ver..." -F Magenta
    switch ($ver) {
        "11" 		   { Client "11" }
        "11-Insider"   { Client "11-Insider" }
        "2012" 		   { Server "2012" }
        "2016" 		   { Server "2016" }
        "2019" 		   { Server "2019" }
        "2022" 		   { Server "2022" }
        "2025" 		   { Server "2025" }
        "2025-Insider" { Server "2025-Insider" }
		default 	   { Write-Host "Unknown OS version: $ver" -F Red }
    }
}

Write-Host "Removing unneeded files and folders" -F Green
dir "$Deploymentshare\Operating Systems\" -R -File | ? { $_.Name -notlike "install.wim" } | del -Fo -R
do {
    $empty = dir "$DeploymentShare\Operating Systems" -R -Directory | ? { $_.GetFiles().Count -eq 0 -and $_.GetDirectories().Count -eq 0 }
    $empty | del -Fo
} while ($empty.Count -gt 0)

$ProductKeyScript = "$RootPath\Scripts\Set-TaskSequenceProductKeys.ps1"
if ($KMSKeys -and (Test-Path $ProductKeyScript)) {
	Write-Host "Setting Product Keys in Task Sequences..." -F Cyan
	& $ProductKeyScript
} else {
	Write-Host "Product Key script not found: $ProductKeyScript" -F Yellow
}
pause