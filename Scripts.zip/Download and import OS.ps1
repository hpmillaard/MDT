$W2012URL = "http://download.microsoft.com/download/6/2/A/62A76ABB-9990-4EFC-A4FE-C7D698DAEB96/9600.17050.WINBLUE_REFRESH.140317-1640_X64FRE_SERVER_EVAL_EN-US-IR3_SSS_X64FREE_EN-US_DV9.ISO"
$W2016URL = "https://software-download.microsoft.com/download/pr/Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh.ISO"
$W2019URL = "https://software-download.microsoft.com/download/pr/17763.737.190906-2324.rs5_release_svc_refresh_SERVER_EVAL_x64FRE_en-us_1.iso"

$RootPath = "D:\MDT"
$Deploymentshare = "$RootPath\DeploymentShare"
$ISOFolder = "$RootPath\ISOs"

################################################################################################################################
$host.ui.RawUI.WindowTitle = $PSCommandPath
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) { Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit }
Import-Module "$ENV:ProgramFiles\Microsoft Deployment Toolkit\bin\MicrosoftDeploymentToolkit.psd1"
New-PSDrive -Name "DS001" -PSProvider MDTProvider -Root "$Deploymentshare"
clear
################################################################################################################################
Function MountISO($ISOPath){
	Write-Host "Mounting $ISO" -ForegroundColor Green
	$beforeMount = (Get-Volume).DriveLetter
	$mountresult = Mount-DiskImage $ISO
	$afterMount = (Get-Volume).DriveLetter
	$script:D = $afterMount | Where {$beforeMount -notcontains $_}
	While (!(Test-Path $D':\Sources\install.wim')) {Start-Sleep 2}
	Write-Host "Install.wim found, starting import" -ForegroundColor Green
}
################################################################################################################################
Function DisMountISO($ISOPath){
	$dismountresult = DisMount-DiskImage -ImagePath $ISOPath
	Write-Host "Dismounted $ISO" -ForegroundColor Green
}
################################################################################################################################

Function W10(){
################################################################################################################################
# Windows 10
################################################################################################################################
If ((get-item filesystem::$ISOFolder\W10\*.ISO).count -lt 1) {& "$ISOFolder\W10\Download Latest W10.ps1"}
rd "DS001:\Operating Systems\W10" -Force -Recurse -ErrorAction SilentlyContinue
md "DS001:\Operating Systems\W10" | Out-Null
rd "DS001:\Task Sequences\W10" -Force -Recurse -ErrorAction SilentlyContinue
md "DS001:\Task Sequences\W10" | Out-Null
Set-Location "DS001:\Operating Systems\W10"
################################################################################################################################
$ISO = (get-item filesystem::$ISOFolder\W10\*X64*EN-US*.ISO).fullname
If ($ISO){
	MountISO($ISO)
	Import-MDTOperatingSystem -Path "DS001:\Operating Systems\W10" -SourcePath $D':\' -DestinationFolder "Windows 10 x64 EN"
	ren 'Windows 10 Enterprise in Windows 10 x64 EN*' 'Windows 10 x64 EN Enterprise'
	ren 'Windows 10 Enterprise for Virtual Desktops in Windows 10 x64 EN*' 'Windows 10 x64 EN Enterprise WVD'
	ren 'Windows 10 Pro in Windows 10 x64 EN*' 'Windows 10 x64 EN Pro'
	del '*in Windows 10 x64 EN*'
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W10" -Name "Windows 10 x64 EN Enterprise" -Template "Client.xml" -ID "W10x64ENENT" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W10\Windows 10 x64 EN Enterprise"
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W10" -Name "Windows 10 x64 EN Enterprise WVD" -Template "Client.xml" -ID "W10x64ENENTWVD" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W10\Windows 10 x64 EN Enterprise WVD"
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W10" -Name "Windows 10 x64 EN Pro" -Template "Client.xml" -ID "W10x64ENPRO" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W10\Windows 10 x64 EN Pro"
	DisMountISO($ISO)
}
################################################################################################################################
$ISO = (get-item filesystem::$ISOFolder\W10\*X64*NL-NL*.ISO).fullname
If ($ISO){
	MountISO($ISO)
	Import-MDTOperatingSystem -Path "DS001:\Operating Systems\W10" -SourcePath $D':\' -DestinationFolder "Windows 10 x64 NL"
	ren 'Windows 10 Enterprise in Windows 10 x64 NL*' 'Windows 10 x64 NL Enterprise'
	ren 'Windows 10 Enterprise for Virtual Desktops in Windows 10 x64 NL*' 'Windows 10 x64 NL Enterprise WVD'
	ren 'Windows 10 Pro in Windows 10 x64 NL*' 'Windows 10 x64 NL Pro'
	del '*in Windows 10 x64 NL*'
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W10" -Name "Windows 10 x64 NL Enterprise" -Template "Client.xml" -ID "W10x64NLENT" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W10\Windows 10 x64 NL Enterprise"
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W10" -Name "Windows 10 x64 NL Enterprise WVD" -Template "Client.xml" -ID "W10x64NLENTWVD" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W10\Windows 10 x64 NL Enterprise WVD"
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W10" -Name "Windows 10 x64 NL Pro" -Template "Client.xml" -ID "W10x64NLPRO" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W10\Windows 10 x64 NL Pro"
	DisMountISO($ISO)
}
################################################################################################################################
$ISO = (get-item filesystem::$ISOFolder\W10\*X86*EN-US*.ISO).fullname
If ($ISO){
	MountISO($ISO)
	Import-MDTOperatingSystem -Path "DS001:\Operating Systems\W10" -SourcePath $D':\' -DestinationFolder "Windows 10 x86 EN"
	ren 'Windows 10 Enterprise in Windows 10 x86 EN*' 'Windows 10 x86 EN Enterprise'
	ren 'Windows 10 Enterprise for Virtual Desktops in Windows 10 x86 EN*' 'Windows 10 x86 EN Enterprise WVD'
	ren 'Windows 10 Pro in Windows 10 x86 EN*' 'Windows 10 x86 EN Pro'
	del '*in Windows 10 x86 EN*'
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W10" -Name "Windows 10 x86 EN Enterprise" -Template "Client.xml" -ID "W10x86ENENT" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W10\Windows 10 x86 EN Enterprise"
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W10" -Name "Windows 10 x86 EN Enterprise WVD" -Template "Client.xml" -ID "W10x86ENENTWVD" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W10\Windows 10 x86 EN Enterprise WVD"
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W10" -Name "Windows 10 x86 EN Pro" -Template "Client.xml" -ID "W10x86ENPRO" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W10\Windows 10 x86 EN Pro"
	DisMountISO($ISO)
}
################################################################################################################################
$ISO = (get-item filesystem::$ISOFolder\W10\*X86*NL-NL*.ISO).fullname
If ($ISO){
	MountISO($ISO)
	Import-MDTOperatingSystem -Path "DS001:\Operating Systems\W10" -SourcePath $D':\' -DestinationFolder "Windows 10 x86 NL"
	ren 'Windows 10 Enterprise in Windows 10 x86 NL*' 'Windows 10 x86 NL Enterprise'
	ren 'Windows 10 Enterprise for Virtual Desktops in Windows 10 x86 NL*' 'Windows 10 x86 NL Enterprise WVD'
	ren 'Windows 10 Pro in Windows 10 x86 NL*' 'Windows 10 x86 NL Pro'
	del '*in Windows 10 x86 NL*'
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W10" -Name "Windows 10 x86 NL Enterprise" -Template "Client.xml" -ID "W10x86NLENT" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W10\Windows 10 x86 NL Enterprise"
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W10" -Name "Windows 10 x86 NL Enterprise WVD" -Template "Client.xml" -ID "W10x86NLENTWVD" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W10\Windows 10 x86 NL Enterprise WVD"
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W10" -Name "Windows 10 x86 NL Pro" -Template "Client.xml" -ID "W10x86NLPRO" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W10\Windows 10 x86 NL Pro"
	DisMountISO($ISO)
}
}

Function W11Insider(){
################################################################################################################################
# Windows 11 Insider
################################################################################################################################
If ((get-item filesystem::$ISOFolder\W11Insider\*.ISO).count -lt 1) {& "$ISOFolder\W11Insider\Download Latest W11 Insider.ps1"}
rd "DS001:\Operating Systems\W11Insider" -Force -Recurse -ErrorAction SilentlyContinue
md "DS001:\Operating Systems\W11Insider" | Out-Null
rd "DS001:\Task Sequences\W11Insider" -Force -Recurse -ErrorAction SilentlyContinue
md "DS001:\Task Sequences\W11Insider" | Out-Null
Set-Location "DS001:\Operating Systems\W11Insider"
################################################################################################################################
$ISO = (get-item filesystem::$ISOFolder\W11Insider\*X64*EN-US*.ISO).fullname
If ($ISO){
	MountISO($ISO)
	Import-MDTOperatingSystem -Path "DS001:\Operating Systems\W11Insider" -SourcePath $D':\' -DestinationFolder "Windows 11 x64 EN Insider"
	ren 'Windows 11 Enterprise in Windows 11 x64 EN Insider*' 'Windows 11 x64 EN Enterprise Insider'
	ren 'Windows 1? Enterprise multi-session in Windows 11 x64 EN Insider*' 'Windows 11 x64 EN Enterprise multi-session Insider'
	ren 'Windows 11 Pro in Windows 11 x64 EN Insider*' 'Windows 11 x64 EN Pro Insider'
	del '*in Windows 11 x64 EN Insider*'
	Write-Host "Other Versions removed, start Task Sequence Import" -ForegroundColor Green
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W11Insider" -Name "Windows 11 x64 EN Enterprise Insider" -Template "Client.xml" -ID "W11x64ENENTInsider" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W11Insider\Windows 11 x64 EN Enterprise Insider"
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W11Insider" -Name "Windows 11 x64 EN Enterprise multi-session Insider" -Template "Client.xml" -ID "W11x64ENENTMSInsider" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W11Insider\Windows 11 x64 EN Enterprise multi-session Insider"
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W11Insider" -Name "Windows 11 x64 EN Pro Insider" -Template "Client.xml" -ID "W11x64ENPROInsider" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W11Insider\Windows 11 x64 EN Pro Insider"
	Write-Host "Task Sequences Imported" -ForegroundColor Green
	DisMountISO($ISO)
}
################################################################################################################################
$ISO = (get-item filesystem::$ISOFolder\W11Insider\*X64*NL-NL*.ISO).fullname
If ($ISO){
	MountISO($ISO)
	Import-MDTOperatingSystem -Path "DS001:\Operating Systems\W11Insider" -SourcePath $D':\' -DestinationFolder "Windows 11 x64 NL Insider"
	ren 'Windows 11 Enterprise in Windows 11 x64 NL Insider*' 'Windows 11 x64 NL Enterprise Insider'
	ren 'Windows 1? Enterprise multi-session in Windows 11 x64 NL Insider*' 'Windows 11 x64 NL Enterprise multi-session Insider'
	ren 'Windows 11 Pro in Windows 11 x64 NL Insider*' 'Windows 11 x64 NL Pro Insider'
	del '*in Windows 11 x64 NL Insider*'
	Write-Host "Other Versions removed, start Task Sequence Import" -ForegroundColor Green
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W11Insider" -Name "Windows 11 x64 NL Enterprise Insider" -Template "Client.xml" -ID "W11x64NLENTInsider" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W11Insider\Windows 11 x64 NL Enterprise Insider"
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W11Insider" -Name "Windows 11 x64 NL Enterprise multi-session Insider" -Template "Client.xml" -ID "W11x64NLENTMSInsider" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W11Insider\Windows 11 x64 NL Enterprise multi-session Insider"
	Import-MDTTaskSequence -Path "DS001:\Task Sequences\W11Insider" -Name "Windows 11 x64 NL Pro Insider" -Template "Client.xml" -ID "W11x64NLPROInsider" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\W11Insider\Windows 11 x64 NL Pro Insider"
	Write-Host "Task Sequences Imported" -ForegroundColor Green
	DisMountISO($ISO)
}
}

Function W2012(){
################################################################################################################################
# Windows 2012 R2
################################################################################################################################
rd "DS001:\Operating Systems\Server 2012" -Force -Recurse -ErrorAction SilentlyContinue
md "DS001:\Operating Systems\Server 2012" | Out-Null
rd "DS001:\Task Sequences\Server 2012" -Force -Recurse -ErrorAction SilentlyContinue
md "DS001:\Task Sequences\Server 2012" | Out-Null
Set-Location "DS001:\Operating Systems\Server 2012"
################################################################################################################################
$ISO = "$ISOFolder\Windows2012EN.ISO"
If (!(Test-Path "$ISO")) {Write-host "$ISO Not found, starting download" -ForeGroundColor Yellow;Start-BitsTransfer $W2012URL "$ISO"}
MountISO($ISO)
Import-MDTOperatingSystem -Path "DS001:\Operating Systems\Server 2012" -SourcePath $D':\' -DestinationFolder "Windows Server 2012 R2" 
ren '*SERVERDATACENTER in Windows Server 2012 R2*' 'Windows Server 2012 R2 DataCenter'
ren '*SERVERDATACENTERCORE in Windows Server 2012 R2*' 'Windows Server 2012 R2 DataCenterCore'
ren '*SERVERSTANDARD in Windows Server 2012 R2*' 'Windows Server 2012 R2 Standard'
ren '*SERVERSTANDARDCORE in Windows Server 2012 R2*' 'Windows Server 2012 R2 StandardCore'
Import-MDTTaskSequence -Path "DS001:\Task Sequences\Server 2012" -Name "Windows 2012 DataCenter" -Template "Server.xml" -ID "W2012DC" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\Server 2012\Windows Server 2012 R2 DATACENTER"
Import-MDTTaskSequence -Path "DS001:\Task Sequences\Server 2012" -Name "Windows 2012 DataCenterCore" -Template "Server.xml" -ID "W2012DCCORE" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\Server 2012\Windows Server 2012 R2 DATACENTERCORE"
Import-MDTTaskSequence -Path "DS001:\Task Sequences\Server 2012" -Name "Windows 2012 Standard" -Template "Server.xml" -ID "W2012STD" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\Server 2012\Windows Server 2012 R2 STANDARD"
Import-MDTTaskSequence -Path "DS001:\Task Sequences\Server 2012" -Name "Windows 2012 StandardCore" -Template "Server.xml" -ID "W2012STDCORE" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\Server 2012\Windows Server 2012 R2 STANDARDCORE"
DisMountISO($ISO)
}

Function W2016(){
################################################################################################################################
# Windows 2016
################################################################################################################################
rd "DS001:\Operating Systems\Server 2016" -Force -Recurse -ErrorAction SilentlyContinue
md "DS001:\Operating Systems\Server 2016" | Out-Null
rd "DS001:\Task Sequences\Server 2016" -Force -Recurse -ErrorAction SilentlyContinue
md "DS001:\Task Sequences\Server 2016" | Out-Null
Set-Location "DS001:\Operating Systems\Server 2016"
################################################################################################################################
$ISO = "$ISOFolder\Windows2016EN.ISO"
If (!(Test-Path "$ISO")) {Write-host "$ISO Not found, starting download" -ForeGroundColor Yellow;Start-BitsTransfer $W2016URL "$ISO"}
MountISO($ISO)
Import-MDTOperatingSystem -Path "DS001:\Operating Systems\Server 2016" -SourcePath $D':\' -DestinationFolder "Windows Server 2016" 
ren '*SERVERDATACENTER in Windows Server 2016*' 'Windows Server 2016 DataCenter'
ren '*SERVERDATACENTERCORE in Windows Server 2016*' 'Windows Server 2016 DataCenterCore'
ren '*SERVERSTANDARD in Windows Server 2016*' 'Windows Server 2016 Standard'
ren '*SERVERSTANDARDCORE in Windows Server 2016*' 'Windows Server 2016 StandardCore'
Import-MDTTaskSequence -Path "DS001:\Task Sequences\Server 2016" -Name "Windows 2016 DataCenter" -Template "Server.xml" -ID "W2016DC" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\Server 2016\Windows Server 2016 DATACENTER"
Import-MDTTaskSequence -Path "DS001:\Task Sequences\Server 2016" -Name "Windows 2016 DataCenterCore" -Template "Server.xml" -ID "W2016DCCORE" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\Server 2016\Windows Server 2016 DATACENTERCORE"
Import-MDTTaskSequence -Path "DS001:\Task Sequences\Server 2016" -Name "Windows 2016 Standard" -Template "Server.xml" -ID "W2016STD" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\Server 2016\Windows Server 2016 STANDARD"
Import-MDTTaskSequence -Path "DS001:\Task Sequences\Server 2016" -Name "Windows 2016 StandardCore" -Template "Server.xml" -ID "W2016STDCORE" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\Server 2016\Windows Server 2016 STANDARDCORE"
DisMountISO($ISO)
}

Function W2019(){
################################################################################################################################
# Windows 2019
################################################################################################################################
rd "DS001:\Operating Systems\Server 2019" -Force -Recurse -ErrorAction SilentlyContinue
md "DS001:\Operating Systems\Server 2019" | Out-Null
rd "DS001:\Task Sequences\Server 2019" -Force -Recurse -ErrorAction SilentlyContinue
md "DS001:\Task Sequences\Server 2019" | Out-Null
Set-Location "DS001:\Operating Systems\Server 2019"
################################################################################################################################
$ISO = "$ISOFolder\Windows2019EN.ISO"
If (!(Test-Path "$ISO")) {Write-host "$ISO Not found, starting download" -ForeGroundColor Yellow;Start-BitsTransfer $W2019URL "$ISO"}
MountISO($ISO)
Import-MDTOperatingSystem -Path "DS001:\Operating Systems\Server 2019" -SourcePath $D':\' -DestinationFolder "Windows Server 2019" 
ren '*SERVERDATACENTER in Windows Server 2019*' 'Windows Server 2019 DataCenter'
ren '*SERVERDATACENTERCORE in Windows Server 2019*' 'Windows Server 2019 DataCenterCore'
ren '*SERVERSTANDARD in Windows Server 2019*' 'Windows Server 2019 Standard'
ren '*SERVERSTANDARDCORE in Windows Server 2019*' 'Windows Server 2019 StandardCore'
Import-MDTTaskSequence -Path "DS001:\Task Sequences\Server 2019" -Name "Windows 2019 DataCenter" -Template "Server.xml" -ID "W2019DC" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\Server 2019\Windows Server 2019 DATACENTER"
Import-MDTTaskSequence -Path "DS001:\Task Sequences\Server 2019" -Name "Windows 2019 DataCenterCore" -Template "Server.xml" -ID "W2019DCCORE" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\Server 2019\Windows Server 2019 DATACENTERCORE"
Import-MDTTaskSequence -Path "DS001:\Task Sequences\Server 2019" -Name "Windows 2019 Standard" -Template "Server.xml" -ID "W2019STD" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\Server 2019\Windows Server 2019 STANDARD"
Import-MDTTaskSequence -Path "DS001:\Task Sequences\Server 2019" -Name "Windows 2019 StandardCore" -Template "Server.xml" -ID "W2019STDCORE" -Version "1.0" -OperatingSystemPath "DS001:\Operating Systems\Server 2019\Windows Server 2019 STANDARDCORE"
DisMountISO($ISO)
}

################################################################################################################################
$OS = @()
$OS += New-Object PSObject -Property @{"OS Name" = "Windows 10"}
$OS += New-Object PSObject -Property @{"OS Name" = "Windows 11 Insider"}
$OS += New-Object PSObject -Property @{"OS Name" = "Windows Server 2012R2"}
$OS += New-Object PSObject -Property @{"OS Name" = "Windows Server 2016"}
$OS += New-Object PSObject -Property @{"OS Name" = "Windows Server 2019"}
Write-Host "Click all the Operating Systems you want to import in MDT in the GUI Window" -ForegroundColor Green
$SelectedOSes = $OS | ogv -Title "Select the Operation System versions you want to import in MDT" -OutputMode Multiple
ForEach ($SelectedOS in $SelectedOSes) {
	If ($SelectedOS -match "10" -and $SelectedOS -notmatch "Insider") {W10}
	If ($SelectedOS -match "Insider") {W11Insider}
	If ($SelectedOS -match "2012") {W2012}
	If ($SelectedOS -match "2016") {W2016}
	If ($SelectedOS -match "2019") {W2019}
}
