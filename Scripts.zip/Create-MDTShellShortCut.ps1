$scriptPath=Join-Path $PSScriptRoot 'MDTShell.ps1'
if(!(Test-Path $scriptPath)){throw "Niet gevonden: $scriptPath"}
$wsh=New-Object -ComObject WScript.Shell
$sc=$wsh.CreateShortcut('C:\Users\Public\Desktop\MDTShell.lnk')
$sc.TargetPath="$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$sc.Arguments="-NoExit -ExecutionPolicy Bypass -File `"$scriptPath`""
$sc.WorkingDirectory=[System.IO.Path]::GetDirectoryName($scriptPath)
$sc.IconLocation="$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe,0"
$sc.Description="MDT Shell (Admin)"
$sc.Save()
Write-Host "Snelkoppeling: $shortcut" -ForegroundColor Green
