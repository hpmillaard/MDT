$host.ui.RawUI.WindowTitle = "Create MDT Deployment Share"

# User will be created for access to the Deploymentshare
$MDTUsername = "MDTDeployment"
$MDTPassword = "MDTD3pl0ym3nt!"
$RootPath = "D:\MDT"
$Deploymentshare = "$RootPath\DeploymentShare"
$OSToImport = "11","2025"
$x86Support = $false

Write-Host "Run as Admin" -f green
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) { Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit }

Write-Host "Remove existing Deploymentshare" -f green
if (Test-Path $Deploymentshare) {
    if (Get-PSDrive -Name "DS001" -EA 0) { Remove-PSDrive -Name "DS001" -Force -EA 0; Remove-MDTPersistentDrive -Name "DS001" -EA 0 }
    if (Get-SmbShare -Name "DeploymentShare" -EA 0) { Remove-SmbShare -Name "DeploymentShare" -Force -Confirm:$false }
    
    $retries = 3
    for ($i = 0; $i -lt $retries; $i++) {
        try {
            Get-ChildItem $Deploymentshare -Recurse -Force -EA 0 | Remove-Item -Force -Recurse -EA Stop
            Remove-Item $Deploymentshare -Force -Recurse -EA Stop
            Write-Host "Deploymentshare removed" -F Green
            break
        } catch {
            if ($i -eq ($retries - 1)) {
                Write-Host "ERROR: Cannot remove Deploymentshare after $retries attempts" -F Red
                pause; exit
            }
            Write-Host "Retry $($i+1)/$retries - Waiting for locks..." -F Yellow
            Start-Sleep -Seconds 2
        }
    }
}

Write-Host "Check for RootPath and create needed folders" -f green
If (!(Test-Path $RootPath.Substring(0, 2))) { clear; Write-Host "$RootPath.Substring(0,2) Drive not found! Please make sure that the drive exists and is formatted" -f red; pause; exit }
$Directories = @{ Apps = "Apps"; CS = "CustomSettings"; Drivers = "Drivers"; Extra = "Extra"; ISO = "ISOs"; Scripts = "Scripts"; SW = "Software" }
foreach ($Key in $Directories.Keys) {
    $FullPath = Join-Path -Path $RootPath -ChildPath $Directories[$Key]
    If (!(Test-Path $FullPath)) { $null = MD $FullPath }
    Set-Variable -Name $Key -Value $FullPath -Scope Global
}

Write-Host "Create Deploymentshare" -f green
Import-Module "$ENV:ProgramFiles\Microsoft Deployment Toolkit\bin\MicrosoftDeploymentToolkit.psd1"
$null = MD "$Deploymentshare"
$null = New-PSDrive -Name "DS001" -PSProvider "MDTProvider" -Root "$Deploymentshare" -Description "MDT Deployment Share" | Add-MDTPersistentDrive
$null = New-SmbShare -Name DeploymentShare -Path "$Deploymentshare" -FullAccess Everyone -Description "MDT Deployment Share" -EA 0

Write-Host "Disable x86" -f green
sp DS001:\ -Name SupportX86 -Value $x86Support

Write-Host "Configure Monitoring" -f green
sp DS001:\ -Name MonitorHost -Value $ENV:COMPUTERNAME
Enable-MDTMonitorService -EventPort 9800 -DataPort 9801

Write-Host "Download Extra" -f Green
Start-BitsTransfer "https://raw.githubusercontent.com/hpmillaard/MDT/master/Extra.zip" "$CS\Extra.zip"
Expand-Archive "$CS\Extra.zip" -Destination $Extra -Force
del "$CS\Extra.zip"
sp DS001:\ -Name 'Boot.x64.ExtraDirectory' -Value "$Extra\x64"
copy "$Extra\x64\*" "$Deploymentshare\Tools\x64\"

Write-Host "Create or Update MDT useraccount and configure the Deploymentshare" -F green
$SecureMDTPassword = ConvertTo-SecureString $MDTPassword -A -F
If (Get-LocalUser -Name $MDTUsername -EA 0) {
    Set-LocalUser -Name $MDTUsername -Password $SecureMDTPassword
} Else {
    New-LocalUser -AccountNeverExpires -Description "User for access to MDT Deploymentshare" -Name $MDTUsername -Password $SecureMDTPassword -PasswordNeverExpires -UserMayNotChangePassword | Add-LocalGroupMember -Group Users
}
ac $Deploymentshare\Control\Bootstrap.ini "SkipBDDWelcome=Yes`nUserid=$MDTUsername`nUserPassword=$MDTPassword`nUserdomain=$ENV:COMPUTERNAME`nDeployRoot=\\$ENV:COMPUTERNAME\DeploymentShare"
Copy "$Scripts\MDTExitNameToGuid.vbs" "$Deploymentshare\Control\MDTExitNameToGuid.vbs"
Copy "$CS\Windows All.ini" "$Deploymentshare\Control\CustomSettings.ini" -Force -EA 0

Write-Host "Download and Import Operating Systems" -f green
$OSArgs = ($OSToImport | ForEach-Object { "`"$_`"" }) -join ","
Start-Process powershell "-NoProfile -ExecutionPolicy Bypass -File `"$Scripts\Download and import OS.ps1`" -ImportOS $OSArgs"

Write-Host "Download and import Apps" -f green
Start-Process powershell "-NoProfile -ExecutionPolicy Bypass -File `"$Scripts\Import-Apps.ps1`""

Write-Host "Update the Deploymentshare" -f green
Update-MDTDeploymentShare -path "DS001:" -Force

Write-Host "Install and configure WDS" -f green
$null = Add-WindowsFeature WDS -EA 0
If ((gwmi -Class Win32_computersystem).PartOfDomain) { $null = WDSutil /Initialize-Server /RemInst:$RootPath\RemoteInstall /Authorize } else { $null = WDSutil /Initialize-Server /RemInst:$RootPath\RemoteInstall /Standalone }
$null = WDSutil /Add-Image /imagetype:boot /ImageFile:"$Deploymentshare\Boot\LiteTouchPE_x64.wim"
$null = WDSutil /Set-Server /AnswerClients:All
If ((Get-WindowsFeature DHCP).InstallState -eq "Installed") { $null = WDSutil /Set-Server /UseDhcpPorts:No /DhcpOption60:Yes }
$null = Start-Service WDSServer

pause
exit