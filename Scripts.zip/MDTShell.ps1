$mdtModule='C:\Program Files\Microsoft Deployment Toolkit\Bin\MicrosoftDeploymentToolkit.psd1'
$dsPath=Join-Path (Split-Path $PSScriptRoot -Parent) 'DeploymentShare'

function Ensure-Elevation{
    $pri=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    if(! $pri.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
        $p=New-Object System.Diagnostics.ProcessStartInfo
        $p.FileName="$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
        $p.Arguments="-NoExit -NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
        $p.Verb='runas';$p.UseShellExecute=$true
        [System.Diagnostics.Process]::Start($p)|Out-Null
        [System.Environment]::Exit(0)
    }
}

function Load-MDT{
    if(! (Test-Path $mdtModule)){throw "MDT module niet gevonden: $mdtModule"}
    Import-Module $mdtModule -ErrorAction Stop
    if(! (Get-PSProvider|?{$_.Name -eq 'MDTProvider'})){throw "MDTProvider niet beschikbaar"}
}

function Mount-DS001{
    $d=Get-PSDrive DS001 -ErrorAction SilentlyContinue
    if($d){Remove-PSDrive DS001 -Scope Global -Force}
    if(! (Test-Path $dsPath)){Write-Warning "Pad niet bereikbaar: $dsPath"}
    New-PSDrive -Name DS001 -PSProvider MDTProvider -Root $dsPath -Description 'MDT Deployment Share' -Scope Global|Out-Null
    Set-Location DS001:\
}

Ensure-Elevation;Load-MDT;Mount-DS001