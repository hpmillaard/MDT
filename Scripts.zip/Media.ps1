$RootPath = "D:\MDT"
$Deploymentshare = "$RootPath\DeploymentShare"

If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) { Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit }
Import-Module "$ENV:ProgramFiles\Microsoft Deployment Toolkit\bin\MicrosoftDeploymentToolkit.psd1"
New-PSDrive -Name "DS001" -PSProvider MDTProvider -Root $Deploymentshare

Function UpdateMedia($Profile){
	Update-MDTMedia "DS001:\Media\$Profile"
	Remove-Item "$RootPath\Media\$Profile\Content\Deploy\Backup" -Force -Recurse -ErrorAction SilentlyContinue
	Remove-Item "$RootPath\Media\$Profile\Content\Deploy\Templates" -Force -Recurse -ErrorAction SilentlyContinue
	Remove-Item "$RootPath\Media\$Profile\Content\Deploy\Audit.log" -Force -ErrorAction SilentlyContinue
}

Function RemoveMedia($Profile){
	Remove-Item "DS001:\Selection Profiles\$Profile"
	Remove-Item "DS001:\Media\$Profile" -ErrorAction SilentlyContinue
	Remove-Item "$RootPath\Media\$Profile" -Force -Recurse -ErrorAction SilentlyContinue
}

Function CreateMedia($Profile,$X86,$X64,$ISO){
	$Definition = '<SelectionProfile><Include path="Applications" /><Include path="Operating Systems\' + $Profile + '" /><Include path="Task Sequences\' + $Profile + '" /></SelectionProfile>'
	New-Item -Path "DS001:\Selection Profiles" -Name $Profile -Definition $Definition -ReadOnly False
	New-Item -Path "DS001:\Media" -enable "True" -Name $Profile -Comments "" -Root "$RootPath\Media\$Profile" -SelectionProfile $Profile -SupportX86 $X86 -SupportX64 $X64 -GenerateISO $ISO -ISOName "$Profile.iso" -Force -Verbose
	MD "$RootPath\Media\$Profile\Content\Deploy\Control\"
	Copy "$RootPath\CustomSettings\Media $Profile.ini" "$RootPath\Media\$Profile\Content\Deploy\Control\CustomSettings.ini" -Force
	Copy "$RootPath\Scripts\MDTExitNameToGuid.vbs" "$RootPath\Media\$Profile\Content\Deploy\Control\MDTExitNameToGuid.vbs"
	Set-Content -Path "$RootPath\Media\$Profile\Content\Deploy\Control\Bootstrap.ini" -Value "[Settings]`r`nPriority=Default`r`n`r`n[Default]`r`nSkipBDDWelcome=Yes"
	UpdateMedia($Profile)
}

Function OS{
	$OS = @()
	$OS += New-Object PSObject -Property @{"OS Name" = "Windows 10"}
	$OS += New-Object PSObject -Property @{"OS Name" = "Windows 10 Insider"}
	$OS += New-Object PSObject -Property @{"OS Name" = "Windows Server 2012R2"}
	$OS += New-Object PSObject -Property @{"OS Name" = "Windows Server 2016"}
	$OS += New-Object PSObject -Property @{"OS Name" = "Windows Server 2019"}

	$SelectedOSes = $OS | ogv -Title "Select the Operation System versions you want to create media for" -OutputMode Multiple
	ForEach ($SelectedOS in $SelectedOSes) {
		If ($SelectedOS -match "10" -and $SelectedOS -notmatch "Insider") {$Script:OSSelected = "W10"}
		If ($SelectedOS -match "Insider") {$Script:OSSelected = "W10Insider"}
		If ($SelectedOS -match "2012") {$Script:OSSelected = "Server 2012"}
		If ($SelectedOS -match "2016") {$Script:OSSelected = "Server 2016"}
		If ($SelectedOS -match "2019") {$Script:OSSelected = "Server 2019"}
	}
}

$qCreate = New-Object System.Management.Automation.Host.ChoiceDescription '&Create', 'Create Media'
$qUpdate = New-Object System.Management.Automation.Host.ChoiceDescription '&Update', 'Update Media'
$qRemove = New-Object System.Management.Automation.Host.ChoiceDescription '&Remove', 'Remove Media'
$MediaOptions = [System.Management.Automation.Host.ChoiceDescription[]]($qCreate,$qUpdate,$qRemove)
$MediaResponse = $host.ui.PromptForChoice('Media', 'What do you want to do?', $MediaOptions, 0)

switch($MediaResponse){
0{	OS
	$qBoth = New-Object System.Management.Automation.Host.ChoiceDescription '&Both', '32 bit and 64 bit'
	$qX86 = New-Object System.Management.Automation.Host.ChoiceDescription 'x&86', '32 bit'
	$qX64 = New-Object System.Management.Automation.Host.ChoiceDescription 'x&64', '64 bit'
	$PlatformOptions = [System.Management.Automation.Host.ChoiceDescription[]]($qBoth,$qX64,$qX86)
	$PlatformResponse = $host.ui.PromptForChoice('Platform', 'Which platforms do you want to support?', $PlatformOptions, 0)
	switch($PlatformResponse){
		0{$X64="True";$X86="True"}
		1{$X86="False";$X64="True"}
		2{$X86="True";$X64="False"}
	}

	$qYes = New-Object System.Management.Automation.Host.ChoiceDescription '&Yes', 'Yes'
	$qNo = New-Object System.Management.Automation.Host.ChoiceDescription '&No', 'No'
	$yesno = [System.Management.Automation.Host.ChoiceDescription[]]($qYes,$qNo)
	$ISOResponse = $host.ui.PromptForChoice('ISO', 'Do you want to create an ISO image?', $yesno, 0)
	switch($ISOResponse){
		0{$ISO="True"}
		1{$ISO="False"}
	}
	CreateMedia $OSSelected $X86 $X64 $ISO
}
1{OS;UpdateMedia $OSSelected}
2{OS;RemoveMedia $OSSelected}
}
