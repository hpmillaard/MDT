$RootPath = "D:\MDT"
$Deploymentshare = "$RootPath\DeploymentShare"
$Extra = "$RootPath\Extra"

If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) { Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit }
Import-Module "$ENV:ProgramFiles\Microsoft Deployment Toolkit\bin\MicrosoftDeploymentToolkit.psd1"
New-PSDrive -Name "DS001" -PSProvider MDTProvider -Root $Deploymentshare

Function UpdateMedia($Profile){
	Update-MDTMedia "DS001:\Media\$Profile"
	Remove-Item "$RootPath\Media\$Profile\Content\Deploy\Backup" -Force -Recurse -EA 0
	Remove-Item "$RootPath\Media\$Profile\Content\Deploy\Templates" -Force -Recurse -EA 0
	Remove-Item "$RootPath\Media\$Profile\Content\Deploy\Audit.log" -Force -EA 0
}

Function RemoveMedia($Profile){
	Remove-Item "DS001:\Selection Profiles\$Profile"
	Remove-Item "DS001:\Media\$Profile" -EA 0
	Remove-Item "$RootPath\Media\$Profile" -Force -Recurse -EA 0
	If ((gci "$RootPath\Media").count -eq 0){Remove-Item "$RootPath\Media" -Force -Recurse -EA 0}
}

Function CreateMedia($Profile){
	$ProfileName = ($Profile -Join "-")
	$Definition = '<SelectionProfile><Include path="Applications" />'
	ForEach ($OS in $Profile) {$Definition += '<Include path="Operating Systems\' + $OS + '"/><Include path="Task Sequences\' + $OS + '"/>'}
	$Definition += '</SelectionProfile>'
	New-Item -Path "DS001:\Selection Profiles" -Name $ProfileName -Definition $Definition -ReadOnly False -EA 0
	New-Item -Path "DS001:\Media" -enable "True" -Name $ProfileName -Comments "" -Root "$RootPath\Media\$ProfileName" -SelectionProfile $ProfileName -SupportX64 True -GenerateISO True -ISOName "$ProfileName.iso" -Force -EA 0
	MD "$RootPath\Media\$ProfileName\Content\Deploy\Control\" -EA 0
	If ($Profile.Count -eq 1 -and $Profile -notmatch "Server") {Copy "$RootPath\CustomSettings\Media $ProfileName.ini" "$RootPath\Media\$ProfileName\Content\Deploy\Control\CustomSettings.ini" -Force} Else {Copy "$RootPath\CustomSettings\Media Multi.ini" "$RootPath\Media\$ProfileName\Content\Deploy\Control\CustomSettings.ini" -Force}
	Copy "$RootPath\Scripts\MDTExitNameToGuid.vbs" "$RootPath\Media\$ProfileName\Content\Deploy\Control\MDTExitNameToGuid.vbs"
	Set-Content -Path "$RootPath\Media\$ProfileName\Content\Deploy\Control\Bootstrap.ini" -Value "[Settings]`r`nPriority=Default`r`n`r`n[Default]`r`nSkipBDDWelcome=Yes"
	UpdateMedia($ProfileName)
	$SettingsXML=New-Object XML
	$SettingsXML.load("$RootPath\Media\$ProfileName\Content\Deploy\Control\Settings.xml")
	$SettingsXML.Settings."Boot.x64.ExtraDirectory" = "$Extra\x64"
	$SettingsXML.save("$RootPath\Media\$ProfileName\Content\Deploy\Control\Settings.xml")
	UpdateMedia($ProfileName)
}

Function OS {
	$OS = @()
	$Script:OSSelected = @()
	If (Test-Path "DS001:\Operating Systems\W11") { $OS += New-Object PSObject -Property @{"OS Name" = "Windows 11"} }
	If (Test-Path "DS001:\Operating Systems\W11-Insider") { $OS += New-Object PSObject -Property @{"OS Name" = "Windows 11 Insider"} }
	If (Test-Path "DS001:\Operating Systems\W2012") { $OS += New-Object PSObject -Property @{"OS Name" = "Windows Server 2012"} }
	If (Test-Path "DS001:\Operating Systems\W2016") { $OS += New-Object PSObject -Property @{"OS Name" = "Windows Server 2016"} }
	If (Test-Path "DS001:\Operating Systems\W2019") { $OS += New-Object PSObject -Property @{"OS Name" = "Windows Server 2019"} }
	If (Test-Path "DS001:\Operating Systems\W2022") { $OS += New-Object PSObject -Property @{"OS Name" = "Windows Server 2022"} }
	If (Test-Path "DS001:\Operating Systems\W2025") { $OS += New-Object PSObject -Property @{"OS Name" = "Windows Server 2025"} }

	$SelectedOSes = $OS | Out-GridView -Title "Select the Operating System(s) for Media creation" -OutputMode Multiple
	ForEach ($SelectedOS in $SelectedOSes) {
		if ($SelectedOS -match "Windows 11$") { $Script:OSSelected += "W11" }
		if ($SelectedOS -match "Windows 11 Insider") { $Script:OSSelected += "W11-Insider" }
		if ($SelectedOS -match "2012") { $Script:OSSelected += "W2012" }
		if ($SelectedOS -match "2016") { $Script:OSSelected += "W2016" }
		if ($SelectedOS -match "2019") { $Script:OSSelected += "W2019" }
		if ($SelectedOS -match "2022") { $Script:OSSelected += "W2022" }
		if ($SelectedOS -match "2025") { $Script:OSSelected += "W2025" }
	}
}

$qCreate = New-Object System.Management.Automation.Host.ChoiceDescription '&Create', 'Create Media'
$qUpdate = New-Object System.Management.Automation.Host.ChoiceDescription '&Update', 'Update Media'
$qRemove = New-Object System.Management.Automation.Host.ChoiceDescription '&Remove', 'Remove Media'
$MediaOptions = [System.Management.Automation.Host.ChoiceDescription[]]($qCreate,$qUpdate,$qRemove)
$MediaResponse = $host.ui.PromptForChoice('Media', 'What do you want to do?', $MediaOptions, 0)

switch($MediaResponse){
0{	OS
	CreateMedia $OSSelected
}
1{$OS = dir DS001:\Media | Out-GridView -Title "Select the media you want to update" -OutputMode Single;UpdateMedia $OS.Name}
2{$OS = dir DS001:\Media | Out-GridView -Title "Select the media you want to remove" -OutputMode Single;RemoveMedia $OS.Name}
}