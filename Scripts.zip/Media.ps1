$RootPath = "D:\MDT"
$Deploymentshare = "$RootPath\DeploymentShare"
$Extra = "$RootPath\Extra"

If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) { Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit }
Import-Module "$ENV:ProgramFiles\Microsoft Deployment Toolkit\bin\MicrosoftDeploymentToolkit.psd1"
New-PSDrive -Name "DS001" -PSProvider MDTProvider -Root $Deploymentshare

Function UpdateMedia($Profile){
	Update-MDTMedia "DS001:\Media\$Profile"
	Remove-Item "$RootPath\Media\$Profile\Content\Deploy\Backup" -Force -Recurse -ErrorAction SilentlyContinue
	Remove-Item "$RootPath\Media\$Profile\Content\Deploy\Templates" -Force -Recurse -ErrorAction SilentlyContinue
	Remove-Item "$RootPath\Media\$Profile\Content\Deploy\Audit.log" -Force -ErrorAction SilentlyContinue
}

Function RemoveMedia($Profile){
	Remove-Item "DS001:\Selection Profiles\$Profile"
	Remove-Item "DS001:\Media\$Profile" -ErrorAction SilentlyContinue
	Remove-Item "$RootPath\Media\$Profile" -Force -Recurse -ErrorAction SilentlyContinue
	If ((gci "$RootPath\Media").count -eq 0){Remove-Item "$RootPath\Media" -Force -Recurse -ErrorAction SilentlyContinue}
}

Function CreateMedia($Profile,$X86){
	$ProfileName = ($Profile -Join "-")
	$Definition = '<SelectionProfile><Include path="Applications" />'
	ForEach ($OS in $Profile) {$Definition += '<Include path="Operating Systems\' + $OS + '"/><Include path="Task Sequences\' + $OS + '"/>'}
	$Definition += '</SelectionProfile>'
	New-Item -Path "DS001:\Selection Profiles" -Name $ProfileName -Definition $Definition -ReadOnly False
	New-Item -Path "DS001:\Media" -enable "True" -Name $ProfileName -Comments "" -Root "$RootPath\Media\$ProfileName" -SelectionProfile $ProfileName -SupportX86 $X86 -SupportX64 True -GenerateISO True -ISOName "$ProfileName.iso" -Force
	MD "$RootPath\Media\$ProfileName\Content\Deploy\Control\"
	If ($Profile.Count -eq 1) {Copy "$RootPath\CustomSettings\Media $ProfileName.ini" "$RootPath\Media\$ProfileName\Content\Deploy\Control\CustomSettings.ini" -Force} Else {Copy "$RootPath\CustomSettings\Media Multi.ini" "$RootPath\Media\$ProfileName\Content\Deploy\Control\CustomSettings.ini" -Force}
	Copy "$RootPath\Scripts\MDTExitNameToGuid.vbs" "$RootPath\Media\$ProfileName\Content\Deploy\Control\MDTExitNameToGuid.vbs"
	Set-Content -Path "$RootPath\Media\$ProfileName\Content\Deploy\Control\Bootstrap.ini" -Value "[Settings]`r`nPriority=Default`r`n`r`n[Default]`r`nSkipBDDWelcome=Yes"
	UpdateMedia($ProfileName)
	$SettingsXML=New-Object XML
	$SettingsXML.load("$RootPath\Media\$ProfileName\Content\Deploy\Control\Settings.xml")
	$SettingsXML.Settings."Boot.x64.ExtraDirectory" = "$Extra\x86"
	$SettingsXML.Settings."Boot.x64.ExtraDirectory" = "$Extra\x64"
	$SettingsXML.save("$RootPath\Media\$ProfileName\Content\Deploy\Control\Settings.xml")
	UpdateMedia($ProfileName)
}

Function OS{
	$OS = @()
	$Script:OSSelected = @()
	If (Test-Path "DS001:\Operating Systems\W10x86"){$OS += New-Object PSObject -Property @{"OS Name" = "Windows 10 x86"}}
	If (Test-Path "DS001:\Operating Systems\W10x64"){$OS += New-Object PSObject -Property @{"OS Name" = "Windows 10 x64"}}
	If (Test-Path "DS001:\Operating Systems\W11x64"){$OS += New-Object PSObject -Property @{"OS Name" = "Windows 11 x64"}}
	If (Test-Path "DS001:\Operating Systems\W11x64Insider"){$OS += New-Object PSObject -Property @{"OS Name" = "Windows 11 x64 Insider"}}
	If (Test-Path "DS001:\Operating Systems\Server 2012"){$OS += New-Object PSObject -Property @{"OS Name" = "Windows Server 2012R2"}}
	If (Test-Path "DS001:\Operating Systems\Server 2016"){$OS += New-Object PSObject -Property @{"OS Name" = "Windows Server 2016"}}
	If (Test-Path "DS001:\Operating Systems\Server 2019"){$OS += New-Object PSObject -Property @{"OS Name" = "Windows Server 2019"}}
	If (Test-Path "DS001:\Operating Systems\Server 2022"){$OS += New-Object PSObject -Property @{"OS Name" = "Windows Server 2022"}}
	$SelectedOSes = $OS | ogv -Title "Select the Operation System version you want to create media for" -OutputMode Multiple
	ForEach ($SelectedOS in $SelectedOSes) {
		If ($SelectedOS -match "10 x86") {$Script:OSSelected += "W10x86"}
		If ($SelectedOS -match "10 x64") {$Script:OSSelected += "W10x64"}
		If ($SelectedOS -match "11 x64" -and $SelectedOS -notmatch "Insider") {$Script:OSSelected += "W11x64"}
		If ($SelectedOS -match "11 x64 Insider") {$Script:OSSelected += "W11x64Insider"}
		If ($SelectedOS -match "2012") {$Script:OSSelected += "Server 2012"}
		If ($SelectedOS -match "2016") {$Script:OSSelected += "Server 2016"}
		If ($SelectedOS -match "2019") {$Script:OSSelected += "Server 2019"}
		If ($SelectedOS -match "2022") {$Script:OSSelected += "Server 2022"}
	}
}

$qCreate = New-Object System.Management.Automation.Host.ChoiceDescription '&Create', 'Create Media'
$qUpdate = New-Object System.Management.Automation.Host.ChoiceDescription '&Update', 'Update Media'
$qRemove = New-Object System.Management.Automation.Host.ChoiceDescription '&Remove', 'Remove Media'
$MediaOptions = [System.Management.Automation.Host.ChoiceDescription[]]($qCreate,$qUpdate,$qRemove)
$MediaResponse = $host.ui.PromptForChoice('Media', 'What do you want to do?', $MediaOptions, 0)

switch($MediaResponse){
0{	OS
	If ($OSSelected -match "x86"){$X86="True"}Else{$X86="False"}
	CreateMedia $OSSelected $X86
}
1{$OS = gci DS001:\Media | Out-GridView -Title "Select the media you want to update" -OutputMode Single;UpdateMedia $OS.Name}
2{$OS = gci DS001:\Media | Out-GridView -Title "Select the media you want to remove" -OutputMode Single;RemoveMedia $OS.Name}
}