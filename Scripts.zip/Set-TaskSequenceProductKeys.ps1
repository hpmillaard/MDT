# Script om ProductKey te injecteren in alle Task Sequences
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Start-Process powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

# Detect Deployment Share via SMB share
$Deploymentshare = $null
$shares = Get-SmbShare | Where-Object { $_.Path -and (Test-Path $_.Path) }

foreach ($share in $shares) {
    # Check if share has MDT structure (Control folder is characteristic)
    if (Test-Path "$($share.Path)\Control\Settings.xml") {
        $Deploymentshare = $share.Path
        Write-Host "Found Deployment Share: $Deploymentshare (via share: $($share.Name))" -F Cyan
        break
    }
}

# Fallback
if (!$Deploymentshare) { 
    $Deploymentshare = "D:\MDT\DeploymentShare"
    Write-Host "Using default Deployment Share: $Deploymentshare" -F Yellow
}

# KMS Keys mapping (edition-based, taal-onafhankelijk)
$KeyMapping = @{
    # Windows 11 & Insider
    'PRO' = 'W269N-WFGWX-YVC9B-4J6C9-T83GX'
    'ENTERPRISE' = 'NPPR9-FWDCX-D2C8J-H872K-2YT43'
    'EDUCATION' = 'NW6C2-QMPVW-D7KKK-3GKT6-VCFB2'
    'PRO-EDUCATION' = '6TP4R-GNPTD-KYYHQ-7B7DP-J447Y'
    'PRO-FOR-WORKSTATIONS' = 'NRG8B-VKK3Q-CXVCJ-9G2XF-6Q84J'
    'ENTERPRISE-MULTI-SESSION' = 'CPWHC-NT2C7-VYW78-DHDB2-PG3GK'
    'SE' = 'YYVX9-NTFWV-6MDM3-9PT4T-4M68B'
    'IOT-ENTERPRISE' = 'KBN8V-HFGQ4-MGXVD-347P6-PDQGT'
    'IOT-ENTERPRISE-SUBSCRIPTION' = 'QPM6N-7J2WJ-P88HH-P3YRH-YY74H'
    # Windows Server 2025 & Insider
    'DATACENTER' = 'D764K-2NDRG-47T6Q-P8T8W-YP6DF'
    'DATACENTERCORE' = 'D764K-2NDRG-47T6Q-P8T8W-YP6DF'
    'STANDARD' = 'TVRH6-WHNXV-R9WG3-9XRFY-MY832'
    'STANDARDCORE' = 'TVRH6-WHNXV-R9WG3-9XRFY-MY832'
}

# Get alle Task Sequences via Control folder
$controlPath = "$Deploymentshare\Control"
$tsFolders = Get-ChildItem $controlPath -Directory | Where-Object { Test-Path "$($_.FullName)\ts.xml" }

foreach ($tsFolder in $tsFolders) {
    $tsXmlPath = "$($tsFolder.FullName)\ts.xml"
    $tsId = $tsFolder.Name  # Folder name = Task Sequence ID
    
    # Match edition en find key
    $matchedKey = $KeyMapping.Keys | Where-Object { $tsId -match "-$_`$" } | Select-Object -First 1
    
    if ($matchedKey) {
        Write-Host "Setting ProductKey for $tsId ($matchedKey)..." -F Green
        
        [xml]$tsXml = Get-Content $tsXmlPath -Encoding UTF8
        
        # Ensure globalVarList exists
        if (!$tsXml.sequence.globalVarList) {
            $null = $tsXml.sequence.AppendChild($tsXml.CreateElement("globalVarList"))
        }
        
        # Set ProductKey variable
        $pkVar = $tsXml.sequence.globalVarList.variable | Where-Object { $_.name -eq "ProductKey" }
        if (!$pkVar) {
            $pkVar = $tsXml.CreateElement("variable")
            $pkVar.SetAttribute("name", "ProductKey")
            $pkVar.SetAttribute("property", "ProductKey")
            $null = $tsXml.sequence.globalVarList.AppendChild($pkVar)
        }
        $pkVar.InnerText = $KeyMapping[$matchedKey]
        
        # Set OverrideProductKey
        $opkVar = $tsXml.sequence.globalVarList.variable | Where-Object { $_.name -eq "OverrideProductKey" }
        if (!$opkVar) {
            $opkVar = $tsXml.CreateElement("variable")
            $opkVar.SetAttribute("name", "OverrideProductKey")
            $opkVar.SetAttribute("property", "OverrideProductKey")
            $null = $tsXml.sequence.globalVarList.AppendChild($opkVar)
        }
        $opkVar.InnerText = "YES"
        
        $tsXml.Save($tsXmlPath)
    }
}

Write-Host "`nAll Task Sequences updated!" -F Cyan
Write-Host "Total Task Sequences processed: $($tsFolders.Count)" -F White
