# Script om ProductKey te injecteren in alle Task Sequences
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Start-Process powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

# Detect Deployment Share via SMB share
$Deploymentshare = $null
$shares = Get-SmbShare | Where-Object { $_.Path -and (Test-Path $_.Path) }

foreach ($share in $shares) {
    # Check if share has MDT structure (Control folder is characteristic)
    if (Test-Path "$($share.Path)\Control\Settings.xml") {
        $Deploymentshare = $share.Path
        Write-Host "Found Deployment Share: $Deploymentshare (via share: $($share.Name))" -F Cyan
        break
    }
}

# Fallback
if (!$Deploymentshare) { 
    $Deploymentshare = "D:\MDT\DeploymentShare"
    Write-Host "Using default Deployment Share: $Deploymentshare" -F Yellow
}

# KMS Keys mapping (edition-based, taal-onafhankelijk)
$KeyMapping = @{
    # Windows 11 & Insider
    'PRO'                         = 'W269N-WFGWX-YVC9B-4J6C9-T83GX'
    'ENTERPRISE'                  = 'NPPR9-FWDCX-D2C8J-H872K-2YT43'
    'EDUCATION'                   = 'NW6C2-QMPVW-D7KKK-3GKT6-VCFB2'
    'PRO-EDUCATION'               = '6TP4R-GNPTD-KYYHQ-7B7DP-J447Y'
    'PRO-FOR-WORKSTATIONS'        = 'NRG8B-VKK3Q-CXVCJ-9G2XF-6Q84J'
    'ENTERPRISE-MULTI-SESSION'    = 'CPWHC-NT2C7-VYW78-DHDB2-PG3GK'
    'SE'                          = 'YYVX9-NTFWV-6MDM3-9PT4T-4M68B'
    'IOT-ENTERPRISE'              = 'KBN8V-HFGQ4-MGXVD-347P6-PDQGT'
    'IOT-ENTERPRISE-SUBSCRIPTION' = 'QPM6N-7J2WJ-P88HH-P3YRH-YY74H'
    # Windows Server 2025 & Insider
    'DATACENTER'                  = 'D764K-2NDRG-47T6Q-P8T8W-YP6DF'
    'DATACENTERCORE'              = 'D764K-2NDRG-47T6Q-P8T8W-YP6DF'
    'STANDARD'                    = 'TVRH6-WHNXV-R9WG3-9XRFY-MY832'
    'STANDARDCORE'                = 'TVRH6-WHNXV-R9WG3-9XRFY-MY832'
}

# Get alle Task Sequences via Control folder
$controlPath = "$Deploymentshare\Control"
$tsFolders = Get-ChildItem $controlPath -Directory | Where-Object { Test-Path "$($_.FullName)\Unattend.xml" }

foreach ($tsFolder in $tsFolders) {
    $unattendPath = "$($tsFolder.FullName)\Unattend.xml"
    $tsId = $tsFolder.Name
    
    # Match edition en find key
    $matchedKey = $KeyMapping.Keys | Where-Object { $tsId -match "-$_`$" } | Select-Object -First 1
    
    if ($matchedKey) {
        Write-Host "Setting ProductKey for $tsId ($matchedKey) in Unattend.xml..." -F Green
        
        [xml]$unattend = Get-Content $unattendPath -Encoding UTF8
        $key = $KeyMapping[$matchedKey]
        
        # Set key in windowsPE pass (UserData)
        $winPE = $unattend.unattend.settings | Where-Object { $_.pass -eq "windowsPE" }
        $setup = $winPE.component | Where-Object { $_.name -eq "Microsoft-Windows-Setup" }
        if ($setup.UserData.ProductKey.Key -ne $null) {
            $setup.UserData.ProductKey.Key = $key
        }
        
        # Set key in specialize pass (Shell-Setup)
        $specialize = $unattend.unattend.settings | Where-Object { $_.pass -eq "specialize" }
        $shellSetup = $specialize.component | Where-Object { $_.name -eq "Microsoft-Windows-Shell-Setup" }
        if ($shellSetup.ProductKey -ne $null) {
            $shellSetup.ProductKey = $key
        }
        
        $unattend.Save($unattendPath)
    }
}

Write-Host "`nAll Task Sequences updated!" -F Cyan
Write-Host "Total Task Sequences processed: $($tsFolders.Count)" -F White
