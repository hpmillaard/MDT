If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs;exit}

$CurrentPath = Split-Path -parent $PSCommandPath

$Builtx64 = "19042.330"
$Builtx86 = "19042.330"
$GUIDx64 = "d8a5d935-23bc-4df2-8936-ee53cc44d500"
$GUIDx86 = "d43434b0-7b06-4fc4-9505-955158da768f"

If ((Get-item "$CurrentPath\$Builtx64Short*").Count -eq 4){write-host "Already latest version";Start-Sleep 10;exit}

$P = "D:\W10ISOs"
IF (!(Test-Path $P)) {MD $P | Out-Null}
copy "$CurrentPath\multi_creatingISO.cmd" "$P"
$Script = "$P\multi_creatingISO.cmd"

Remove-Item "$P\uup\*.1.*" -Recurse -Force -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
Remove-Item "$P\uup\*" -Exclude $Builtx64 -Force -ErrorAction SilentlyContinue -WarningAction SilentlyContinue

Function MakeISO($Name,$Built,$Lang,$Bits,$GUID){
	Write-Host $Name -ForegroundColor Green
	$BitsShort = $Bits.Substring($Bits.get_Length()-2)
	"call", $Script, $Built, $Lang, $Bits, $GUID, ">$P\$Name.log" -Join " " | Out-File $P\$Name-$Built.bat -encoding ascii -Force
	Do {
		$App = Start-Process -FilePath $P\$Name-$Built.bat -PassThru -WindowStyle Hidden
		Do {$content = get-content $P\$Name.log -tail 1 -ErrorAction SilentlyContinue| where {$_ -match "Press any key" -or $_ -match "ECHO is off" -or $_ -match "error while downloading"}} until($content)
		taskkill /pid $App.ID
	} until (Test-Path $P\*$BitsShort*$Lang*.ISO)
	del $P\$Name.log
	del $P\$Name-$Built.bat
	Write-Host "Moving ISO" -ForegroundColor Green
	move "$P\*.iso" "$CurrentPath" -Force
}

If (!(Test-Path "$CurrentPath\$Builtx64*x64*en-us*.ISO")) {MakeISO "W10ENx64" $Builtx64 "en-us" "amd64" $GUIDx64}
If (!(Test-Path "$CurrentPath\$Builtx86*x86*en-us*.ISO")) {MakeISO "W10ENx86" $Builtx86 "en-us" "x86" $GUIDx86}
If (!(Test-Path "$CurrentPath\$Builtx64*x64*nl-nl*.ISO")) {MakeISO "W10NLx64" $Builtx64 "nl-nl" "amd64" $GUIDx64}
If (!(Test-Path "$CurrentPath\$Builtx86*x86*nl-nl*.ISO")) {MakeISO "W10NLx86" $Builtx86 "nl-nl" "x86" $GUIDx86}

rd $P -Force -Recurse
