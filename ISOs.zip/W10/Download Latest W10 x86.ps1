If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs;exit}

$CurrentPath = Split-Path -parent $PSCommandPath

$Built = "19044.1348"
$GUID = "0cda7cda-db05-41e5-9b68-e061b65f3c8e"

If ($Built.StartsWith("10.0.")) {$BuiltShort = $Built.Substring(5)} Else {$BuiltShort = $Built}
If ((Get-item "$CurrentPath\$BuiltShort*").Count -eq 2){write-host -Fore Orange "Already latest version, script will stop";Start-Sleep 10;exit}ELSE{Write-Host -Fore Green "Start download version: $BuiltShort"}

$EN = "https://uup.rg-adguard.net/api/GetFiles?id=$GUID&lang=en-us&edition=all&pack=en-US&creatingISO_cmd=yes"
$NL = "https://uup.rg-adguard.net/api/GetFiles?id=$GUID&lang=nl-nl&edition=all&pack=en-US&creatingISO_cmd=yes"

$P = "D:\W10ISOs"
IF (!(Test-Path $P)) {MD $P | Out-Null}

Write-Host -Fore Green "Downloading components"
Start-BitsTransfer ((curl $EN).Links | ? href -match "multi").href $P\EN.cmd
Start-BitsTransfer ((curl $NL).Links | ? href -match "multi").href $P\NL.cmd
Start-BitsTransfer https://uup.rg-adguard.net/dl/convert_lite.cab $P\convert_lite.cab
Expand $P\convert_lite.cab -f:* $P
del $P\convert_lite.cab

(Get-Content $P\bin\convert-UUP.cmd) -replace "pause >nul","" | Set-Content $P\bin\convert-UUP.cmd
(Get-Content $P\EN.cmd) -replace "pause","" -replace "color 0b","color 0b`n`rGOTO :DownListLang" | Set-Content $P\EN.cmd
(Get-Content $P\NL.cmd) -replace "pause","" -replace "color 0b","color 0b`n`rGOTO :DownListLang" | Set-Content $P\NL.cmd

cls
If (!(Test-Path $CurrentPath\$Built*x86*EN-US*.ISO)) {
	Write-Host -Fore Green "Start Download W10 x86 EN"
	start "$P\EN.cmd" -wait
}
If (!(Test-Path $CurrentPath\$Built*x86*NL-NL*.ISO)) {
	Write-Host -Fore Green "Start Download W10 x86 NL"
	start "$P\NL.cmd" -wait
}

Write-Host -Fore Green "Moving ISO"
move "$P\*.iso" "$CurrentPath" -Force

Write-Host -Fore Green "Cleanup"
remove-item "$CurrentPath\*.iso" -exclude *$Builtx64Short*
rd $P -Force -Recurse
