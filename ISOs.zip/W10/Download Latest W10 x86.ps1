If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs;exit}

$Lang = "EN-US","NL-NL"
$ver = "W10"
$bit = "x86"

Write-Host -F Green "Determining Latest Version $ver $bit"
$SearchString = "19045"
$Links = (curl (@("https://uupdump.net/known.php?q=$SearchString", "https://windows.hyp.one/known.php?q=$SearchString") | % { try { curl $_ -UseB -EA Stop } catch {} } | ? { $_.StatusCode -eq 200 } | % { $_.BaseResponse.ResponseUri } | Select -First 1).OriginalString).Links
$Latest = ($Links | ? innertext -match $bit)[0]
$GUID = $Latest.href.Split("=")[1]
$array = $Latest.InnerText.Split()
For($i = 0; $i -lt $array.length; $i++){If ($array[$i].contains(".")){$Built = $array[$i]}}
If ($Built.StartsWith("(")){$Built = $Built.Substring(1)}
If ($Built.EndsWith(")")){$Built = $Built -replace ".$"}
If ($Built.StartsWith("10.0.")) {$Built = $Built.Substring(5)}

$P = "D:\$ver`ISOs"
IF (Test-Path "$P\*.iso") {Write-Host -F Green "Found previous download folder`nMoving ISO";move "$P\*.iso" "$PSScriptRoot" -Force} ELSE {MD $P -EA 0 | Out-Null}

If ((gi "$PSScriptRoot\$Built*$bit*.iso").Count -eq $Lang.count){write-host -Fore Yellow "Already latest version for $ver $bit $Built, script will stop";Start-Sleep 10;exit}ELSE{Write-Host -F Green "Start download version: $Built and GUID: $GUID"}

Write-Host -F Green "Downloading components"
If (!(Test-Path $P\bin\convert-UUP.cmd)) {
	Start-BitsTransfer https://uup.rg-adguard.net/dl/convert_lite.cab $P\convert_lite.cab
	Expand $P\convert_lite.cab -f:* $P | Out-Null
	del $P\convert_lite.cab
	(gc $P\bin\convert-UUP.cmd) -replace "pause >nul","" | sc $P\bin\convert-UUP.cmd
}

Function Download {
	param([string]$language)
	If (!(Test-Path $PSScriptRoot\$Built*$bit*$language*.ISO)) {
		Write-Host -F Green "Download $ver $bit $language"
		$URL = "https://uup.rg-adguard.net/api/GetFiles?id=$GUID&lang=$language&edition=all&pack=en-US&creatingISO_cmd=yes"
		$cmd = "$P\$ver-$language-$bit.cmd"
		curl ((curl $URL).Links | ? innertext -match "multi").href -outfile "$cmd"
		(gc "$cmd") -replace "pause","" -replace "color 0b","color 0b`n`rGOTO :DownListLang" | sc "$cmd"
		start $cmd -wait
		Write-Host -F Green "Moving ISO"
		move "$P\*.iso" "$PSScriptRoot" -Force
	}
}

Foreach ($L in $Lang){Download -Language $L}

If ((gi "$PSScriptRoot\$Built*").Count -eq $Lang.count){
	Write-Host -F Green "Cleanup"
	del "$PSScriptRoot\*.iso" -exclude *$Built*,*x64*
	rd $P -Force -Recurse
}