If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs;exit}

$Lang = "EN-US","NL-NL"
$ver = "W11"
$bit = "x64"

$CurrentPath = Split-Path -parent $PSCommandPath

Write-Host -Fore Green "Determining Latest Version $ver $bit"
$Links = (curl https://uupdump.net/known.php).Links
$Latest = ($Links | ? innertext -match "insider" | ? innertext -match "amd64" | ? innertext -notmatch "update")[0]
$Built = $Latest.InnerText.Split()[4]
$GUID = $Latest.href.Split("=")[1]

If ($Built.StartsWith("10.0.")) {$BuiltShort = $Built.Substring(5)} Else {$BuiltShort = $Built}
If ((Get-item "$CurrentPath\$BuiltShort*").Count -eq 2){write-host -Fore Orange "Already latest version, script will stop";Start-Sleep 10;exit}ELSE{Write-Host -Fore Green "Start download version: $BuiltShort"}

$P = "D:\$ver`ISOs"
IF (!(Test-Path $P)) {MD $P | Out-Null}
Write-Host -Fore Green "Downloading components"
If (!(Test-Path $P\bin\convert-UUP.cmd)) {
	Start-BitsTransfer https://uup.rg-adguard.net/dl/convert_lite.cab $P\convert_lite.cab
	Expand $P\convert_lite.cab -f:* $P | Out-Null
	del $P\convert_lite.cab
	(Get-Content $P\bin\convert-UUP.cmd) -replace "pause >nul","" | Set-Content $P\bin\convert-UUP.cmd
}

Function Download {
	param([string]$language)
	If (!(Test-Path $CurrentPath\$Built*$bit*$language*.ISO)) {
		Write-Host -Fore Green "Download $ver $bit $language"
		$URL = "https://uup.rg-adguard.net/api/GetFiles?id=$GUID&lang=$language&edition=all&pack=en-US&creatingISO_cmd=yes"
		$cmd = "$P\$ver-$language-$bit.cmd"
		Start-BitsTransfer ((curl $URL).Links | ? href -match "multi").href "$cmd"
		(Get-Content "$cmd") -replace "pause","" -replace "color 0b","color 0b`n`rGOTO :DownListLang" | Set-Content "$cmd"
		start $cmd -wait
		Write-Host -Fore Green "Moving ISO"
		move "$P\*.iso" "$CurrentPath" -Force
	}
}

Foreach ($l in $lang){Download -language $l}

Write-Host -Fore Green "Cleanup"
remove-item "$CurrentPath\*.iso" -exclude *$BuiltShort*,"*RELEASE_SVC_PROD*"
rd $P -Force -Recurse
