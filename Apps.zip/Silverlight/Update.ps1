clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
Function Get-RedirectedUrl {
	Param ([Parameter(Mandatory=$true)][String]$URL)
	$request = [System.Net.WebRequest]::Create($url)
	$request.AllowAutoRedirect=$false
	$response=$request.GetResponse()
	$response.GetResponseHeader("Location")
}
Start-BitsTransfer (Get-RedirectedUrl -URL 'http://go.microsoft.com/fwlink/?LinkId=229320') $curpath\Silverlight32.exe
Start-BitsTransfer (Get-RedirectedUrl -URL 'http://go.microsoft.com/fwlink/?LinkId=229321') $curpath\Silverlight64.exe
