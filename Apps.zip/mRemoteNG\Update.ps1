clear
$host.ui.RawUI.WindowTitle = (Get-Item $PSScriptRoot).Name
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Start-BitsTransfer ((curl https://api.github.com/repos/mRemoteNG/mRemoteNG/releases/latest -UseBasicParsing | convertfrom-json).assets | ? name -match msi).browser_download_url "$PSScriptRoot\mRemoteNG.msi"