clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
$Versions = (curl https://github.com/brave/brave-browser/releases -UseBasicParsing).Links
$Links = (curl ('https://github.com' + ($Versions | ? outerhtml -match "desktop release").href) -UseBasicParsing).Links
curl ('https://github.com/' + ($Links | ? outerhtml -match "BraveBrowserSilentSetup.exe").href) -OutFile $curpath\BraveSilentx64.exe
curl ('https://github.com/' + ($Links | ? outerhtml -match "BraveBrowserSilentSetup32.exe").href) -OutFile $curpath\BraveSilentx86.exe
