clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -U '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
If ((gwmi win32_operatingsystem).OSLanguage -eq 1043){$Lang = "NL"}Else{$Lang = "EN"}
If ($ENV:PROCESSOR_ARCHITECTURE -match 86){$strVer = "32";$Prog = $ENV:ProgramFiles}
If ($ENV:PROCESSOR_ARCHITECTURE -match 64){$strVer = "64";$Prog = ${ENV:ProgramFile(x86)}}
Start "$PSScriptRoot\Firefox_$Lang_$strVer.exe" "-ms" -Wait

gci ([environment]::getfolderpath("commondesktop")) | ? name -match "firefox") | del -EA 0
cp "$PSScripRoot\override.ini" "$Prog\Mozilla Firefox\browser\override.ini" -EA 0
cp "$PSScripRoot\mozilla.cfg" "$Prog\Mozilla Firefox\mozilla.cfg" -EA 0
cp "$PSScripRoot\local-settings.js" "$Prog\Mozilla Firefox\defaults\pref\local-settings.js" -EA 0

change user /execute
Log "Finished installation"
exit 0