clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
curl ((curl "https://mremoteng.org/download").Links | where {$_.outerhtml -match "success" -and $_.href -match "msi"}).href -OutFile $curpath\mRemoteNG.msi
