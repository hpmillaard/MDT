clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
[System.Net.ServicePointManager]::DefaultConnectionLimit = 1024
Function Get-RedirectedUrl {
	Param ([Parameter(Mandatory=$true)][String]$URL)
	$request = [System.Net.WebRequest]::Create($url)
	$request.AllowAutoRedirect=$false
	$response=$request.GetResponse()
	$response.GetResponseHeader("Location")
}
Start-BitsTransfer (Get-RedirectedUrl -URL 'https://download.mozilla.org/?product=firefox-latest&os=win&lang=en-US') $curpath\FireFox_EN_32.exe
Start-BitsTransfer (Get-RedirectedUrl -URL 'https://download.mozilla.org/?product=firefox-latest&os=win64&lang=en-US') $curpath\FireFox_EN_64.exe
Start-BitsTransfer (Get-RedirectedUrl -URL 'https://download.mozilla.org/?product=firefox-latest&os=win&lang=nl') $curpath\FireFox_NL_32.exe
Start-BitsTransfer (Get-RedirectedUrl -URL 'https://download.mozilla.org/?product=firefox-latest&os=win64&lang=nl') $curpath\FireFox_NL_64.exe
