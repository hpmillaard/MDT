clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -U '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
winget install Mozilla.Firefox -e --accept-source-agreements --scope machine
gci ([environment]::getfolderpath("desktop")) | ? name -match "FireFox" | del -EA 0
gci ([environment]::getfolderpath("commondesktop")) | ? name -match "FireFox" | del -EA 0

If ($ENV:PROCESSOR_ARCHITECTURE -match 86){$Prog = $ENV:ProgramFiles}
If ($ENV:PROCESSOR_ARCHITECTURE -match 64){$Prog = ${ENV:ProgramFile(x86)}}
copy "$PSScripRoot\override.ini" "$Prog\Mozilla Firefox\browser\override.ini" -EA 0
copy "$PSScripRoot\mozilla.cfg" "$Prog\Mozilla Firefox\mozilla.cfg" -EA 0
copy "$PSScripRoot\local-settings.js" "$Prog\Mozilla Firefox\defaults\pref\local-settings.js" -EA 0

change user /execute
Log "Finished installation"
exit 0