clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -U '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
$arg = "/s INSTALL_SILENT=1 AUTO_UPDATE=0 WEB_ANALYTICS=0 REBOOT=0 STATIC=0 SPONSORS=0 REMOVEOUTOFDATEJRES=1"
If ($ENV:PROCESSOR_ARCHITECTURE -match 86){
	Start "$PSScriptRoot\jre8.exe" "$arg INSTALLDIR=""$ENV:ProgramFiles\Java\jre8""" -Wait
	reg import "$PSScriptRoot\java.reg"
	$jver = Get-ItemPropertyValue "HKLM:\SOFTWARE\JavaSoft\Java Web Start\" -Name "CurrentVersion"
	sp "HKLM:\SOFTWARE\JavaSoft\JavaSoft\Java Plug-in\$jver\" -Name "UseNewWebPlugin" -Value 0 -Type DWORD
}

If ($ENV:PROCESSOR_ARCHITECTURE -match 64){
	Start "$PSScriptRoot\jre8.exe" "$arg INSTALLDIR=""${ENV:ProgramFiles(x86)}\Java\jre8""" -Wait
	reg import "$PSScriptRoot\java.reg"
	$jver = Get-ItemPropertyValue "HKLM:\SOFTWARE\Wow6432Node\JavaSoft\Java Web Start\" -Name "CurrentVersion"
	sp "HKLM:\SOFTWARE\Wow6432Node\JavaSoft\Java Plug-in\$jver\" -Name "UseNewWebPlugin" -Value 0 -Type DWORD
	
	Start "$PSScriptRoot\jre8-x64.exe" "$arg INSTALLDIR=""$ENV:ProgramFiles\Java\jre8""" -Wait
	reg import "$PSScriptRoot\java-X64.reg"
	$jver = Get-ItemPropertyValue "HKLM:\SOFTWARE\JavaSoft\Java Web Start\" -Name "CurrentVersion"
	sp "HKLM:\SOFTWARE\JavaSoft\Java Plug-in\$jver\" -Name "UseNewWebPlugin" -Value 0 -Type DWORD
}

gci ([environment]::GetFolderPath("commonprograms")) | ? name -match java | del -r

change user /execute
Log "Finished installation"
exit 0