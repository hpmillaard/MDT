// Remove Help -> Repair Adobe Reader Installation 
app.hideMenuItem("DetectAndRepair"); 
// Remove Help -> Online Support 
app.hideMenuItem("OnlineSupport"); 
// Remove Help -> Online Support - Knowledge Base 
app.hideMenuItem("KnowledgeBase"); 
// Remove Help -> Online Support - Adobe Support Programs 
app.hideMenuItem("AdobeExpertSupport"); 
// Remove Help -> Online Support - Adobe User Community 
app.hideMenuItem("AdobeUserCommunity"); 
// Remove Help -> Online Support - Accessibility Resource Center 
app.hideMenuItem("AccessOnline"); 
// Remove Help -> Online Support - Generate System Report 
app.hideMenuItem("SystemInformation");
// Remove Help -> Check for Updates
app.hideMenuItem("Updates");
// Remove Help -> Purchase Adobe Acrobat
app.hideMenuItem("Weblink:BuyAcrobat");
// Remove Help -> Digital Editions
app.hideMenuItem("eBook:Digital Edition Services");
// Remove Help -> Improvement Program Options
app.hideMenuItem("UsageMeasurement");
// Remove File -> Share Files Using SendNowOnline
app.hideMenuItem("SPAObject 51");
// Remove File -> CreatePDF Online
app.hideMenuItem("SPAObject 47");
// Remove Create PDF Online + Toolbar button
app.hideMenuItem("WebServices.CreatePDF");
app.hideToolbarButton("Weblink:CreatePDF");
// Remove Collaborate + Toolbar button
app.hideMenuItem("Annots:FileCollaboration");
app.HideToolbarButton("Annots:CollabToolButton");
// Remove View -> Read Out Loud
app.hideMenuItem("ReadAloud")
// Remove Document Security
app.hideMenuItem("DIGSIG:DigitalSignatures");
app.hideMenuItem("ppklite:SecPolicySecureTask");
app.hideMenuItem("ppklite:UserSettings");
app.hideMenuItem("PUBSEC:AddressBook");