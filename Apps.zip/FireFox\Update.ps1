clear
$host.ui.RawUI.WindowTitle = (Get-Item $PSScriptRoot).Name
[System.Net.ServicePointManager]::DefaultConnectionLimit = 1024
Function Get-RedirectedUrl($URL){
	$request = [System.Net.WebRequest]::Create($URL)
	$request.AllowAutoRedirect=$false
	$response=$request.GetResponse()
	$response.GetResponseHeader("Location")
}
Start-BitsTransfer (Get-RedirectedUrl -URL 'https://download.mozilla.org/?product=firefox-latest&os=win&lang=en-US') $PSScriptRoot\FireFox_EN_32.exe
Start-BitsTransfer (Get-RedirectedUrl -URL 'https://download.mozilla.org/?product=firefox-latest&os=win64&lang=en-US') $PSScriptRoot\FireFox_EN_64.exe
Start-BitsTransfer (Get-RedirectedUrl -URL 'https://download.mozilla.org/?product=firefox-latest&os=win&lang=nl') $PSScriptRoot\FireFox_NL_32.exe
Start-BitsTransfer (Get-RedirectedUrl -URL 'https://download.mozilla.org/?product=firefox-latest&os=win64&lang=nl') $PSScriptRoot\FireFox_NL_64.exe
