clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
Start-BitsTransfer ((curl 'https://filezilla-project.org/download.php?type=client').Links | ? href -match ".exe").href $curpath\FileZilla.exe
