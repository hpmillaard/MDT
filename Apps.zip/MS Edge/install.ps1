clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -U '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
winget install Microsoft.Edge -e --accept-source-agreements --scope machine
regedit /s "$PSScriptRoot\Edge.reg"

Get-Service | ? name -match edgeupdate | Set-Service -StartupType Disabled
Get-Service | ? name -match Edge | Set-Service -StartupType Disabled
Get-ScheduledTask | ? Taskname -Match EdgeUpdateTask | Unregister-ScheduledTask -Confirm:$false

If ($ENV:PROCESSOR_ARCHITECTURE -match 64){$Prog = ${ENV:ProgramFiles(x86)}}Else{$Prog = $ENV:ProgramFiles}
cp "$PSScriptRoot\master_preferences" "$Prog\Microsoft\Edge\Application\master_preferences" -Force -EA 0

gci ([environment]::getfolderpath("desktop")) | ? name -match "Edge" | del -EA 0
gci ([environment]::getfolderpath("commondesktop")) | ? name -match "Edge" | del -EA 0

change user /execute
Log "Finished installation"
exit 0