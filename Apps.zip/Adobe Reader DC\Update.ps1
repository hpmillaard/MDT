clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
If (!(Test-Path $curpath\AcroRdrDC1900820071_nl_NL.exe)){Start-BitsTransfer http://ardownload.adobe.com/pub/adobe/reader/win/AcrobatDC/1900820071/AcroRdrDC1900820071_nl_NL.exe $curpath\AcroRdrDC1900820071_nl_NL.exe}
If (!(Test-Path $curpath\AcroRdrDC2100120155_en_US.exe)){Start-BitsTransfer http://ardownload.adobe.com/pub/adobe/reader/win/AcrobatDC/2100120155/AcroRdrDC2100120155_en_US.exe $curpath\AcroRdrDC2100120155_en_US.exe}
$Link1 = 'https://www.adobe.com/devnet-docs/acrobatetk/tools/ReleaseNotesDC/' + ((curl https://www.adobe.com/devnet-docs/acrobatetk/tools/ReleaseNotesDC/index.html -UseBasicParsing).links | ? href -match dccont)[0].href
$Link2 = ((curl $Link1 -UseBasicParsing).Links | ? href -match AcroRdrDC)[0].href
Start-BitsTransfer $Link2 $curpath\AcroRdrDCUpdate.msp
