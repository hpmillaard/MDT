clear

$host.ui.RawUI.WindowTitle = (Get-Item $PSScriptRoot).Name
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$EN = ((curl "https://rdc.adobe.io/reader/products?lang=en&site=enterprise&os=Windows%2011&api_key=dc-get-adobereader-cdn" -UseBasicParsing) | ConvertFrom-Json).products.reader.version.replace(".","")
If (!(Test-Path $PSScriptRoot\AcroRdrDC_en_US.exe)){Start-BitsTransfer "http://ardownload.adobe.com/pub/adobe/reader/win/AcrobatDC/$EN/AcroRdrDC$EN`_en_US.exe" $PSScriptRoot\AcroRdrDC_en_US.exe}

$NL = ((curl "https://rdc.adobe.io/reader/products?lang=nl&site=enterprise&os=Windows%2011&api_key=dc-get-adobereader-cdn" -UseBasicParsing) | ConvertFrom-Json).products.reader.version.replace(".","")
If (!(Test-Path $PSScriptRoot\AcroRdrDC_nl_NL.exe)){Start-BitsTransfer "http://ardownload.adobe.com/pub/adobe/reader/win/AcrobatDC/$NL/AcroRdrDC$NL`_nl_NL.exe" $PSScriptRoot\AcroRdrDC_nl_NL.exe}

$MUI = ((curl "https://rdc.adobe.io/reader/products?lang=mui&site=enterprise&os=Windows%2011&api_key=dc-get-adobereader-cdn" -UseBasicParsing) | ConvertFrom-Json).products.reader.version[0].replace(".","")
Start-BitsTransfer "https://ardownload2.adobe.com/pub/adobe/reader/win/AcrobatDC/$MUI/AcroRdrDCUpd$MUI`.msp" "$PSScriptRoot\AcroRdrDCUpdate.msp"
