clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
Start-BitsTransfer "https://go.microsoft.com/fwlink/?linkid=2108834&Channel=Stable&language=en" $curpath\EdgeEN.exe
Start-BitsTransfer "https://go.microsoft.com/fwlink/?linkid=2108834&Channel=Stable&language=nl" $curpath\EdgeNL.exe