clear
$host.ui.RawUI.WindowTitle = (gi $PSScriptRoot).Name
Start-BitsTransfer ((curl https://edgeupdates.microsoft.com/api/products -UseBasicParsing | convertfrom-json).releases | ? architecture -match x64)[0].artifacts.location $PSScriptRoot\MicrosoftEdgeEnterpriseX64.msi
Start-BitsTransfer ((curl https://edgeupdates.microsoft.com/api/products -UseBasicParsing | convertfrom-json).releases | ? architecture -match x86)[0].artifacts.location $PSScriptRoot\MicrosoftEdgeEnterpriseX86.msi
Start-BitsTransfer "https://go.microsoft.com/fwlink/?linkid=2108834&Channel=Stable&language=en" $PSScriptRoot\EdgeEN.exe
Start-BitsTransfer "https://go.microsoft.com/fwlink/?linkid=2108834&Channel=Stable&language=nl" $PSScriptRoot\EdgeNL.exe