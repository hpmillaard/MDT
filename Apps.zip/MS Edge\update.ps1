clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
Start-BitsTransfer ((curl https://edgeupdates.microsoft.com/api/products -UseBasicParsing | convertfrom-json).releases | ? architecture -match x64)[0].artifacts.location $curpath\MicrosoftEdgeEnterpriseX64.msi
Start-BitsTransfer ((curl https://edgeupdates.microsoft.com/api/products -UseBasicParsing | convertfrom-json).releases | ? architecture -match x86)[0].artifacts.location $curpath\MicrosoftEdgeEnterpriseX86.msi
Start-BitsTransfer "https://go.microsoft.com/fwlink/?linkid=2108834&Channel=Stable&language=en" $curpath\EdgeEN.exe
Start-BitsTransfer "https://go.microsoft.com/fwlink/?linkid=2108834&Channel=Stable&language=nl" $curpath\EdgeNL.exe