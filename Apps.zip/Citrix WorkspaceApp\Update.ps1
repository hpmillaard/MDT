clear

$host.ui.RawUI.WindowTitle = (Get-Item $PSScriptRoot).Name
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$URL = ((curl "https://www.citrix.com/downloads/workspace-app/windows/workspace-app-for-windows-latest.html").Links | ? href -match "ctx-dl-eula-external").rel
Start-BitsTransfer https:$URL $PSScriptRoot\CitrixWorkspaceAppWeb.exe
