clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
$Links = (curl https://www.wireshark.org/download.html).Links
clear
Write-Host -Fore Green "Download Wireshark 32bit"
Start-BitsTransfer ($Links | ? href -match "Wireshark-win32-")[0].href $curpath\Wireshark-x32.exe
clear
Write-Host -Fore Green "Download Wireshark 64bit"
Start-BitsTransfer ($Links | ? href -match "Wireshark-win64-")[0].href $curpath\Wireshark-x64.exe
clear
Write-Host -Fore Green "Download npcap"
Start-Bitstransfer ("https://nmap.org/npcap/" + ((curl https://nmap.org/npcap/).Links | ? href -match exe).href) $curpath\npcap.exe
