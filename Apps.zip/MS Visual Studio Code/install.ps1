clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -U '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
winget install Microsoft.VisualStudioCode -e --accept-source-agreements --scope machine
winget install Git.Git -e --source winget --scope machine
winget install Microsoft.Bicep -e --scope machine
$env:PATH = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
code --install-extension eamodio.gitlens --force
code --install-extension github.copilot --force
code --install-extension github.copilot-chat --force
code --install-extension JannisX11.batch-rename-extension --force
code --install-extension josin.kusto-syntax-highlighting --force
code --install-extension leodevbro.blockman --force
code --install-extension ms-azuretools.vscode-azureresourcegroups --force
code --install-extension ms-azuretools.vscode-bicep --force
code --install-extension ms-dotnettools.vscode-dotnet-runtime --force
code --install-extension ms-vscode.azure-account --force
code --install-extension ms-vscode.powershell --force
code --install-extension msazurermtools.azurerm-vscode-tools --force
code --install-extension redhat.vscode-yaml --force
code --install-extension sandcastle.vscode-open --force

change user /execute
Log "Finished installation"
exit 0