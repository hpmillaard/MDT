clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
Start-BitsTransfer 'https://www.dropbox.com/download?full=1&plat=win' $curpath\Dropbox.exe
