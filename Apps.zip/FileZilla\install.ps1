clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -U '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
If ($ENV:PROCESSOR_ARCHITECTURE -match 86){$strVer = "32"}
If ($ENV:PROCESSOR_ARCHITECTURE -match 64){$strVer = "64"}
Start "$PSScriptRoot\FileZilla-x$strVer.exe" "/S /user=all" -Wait

change user /execute
Log "Finished installation"
exit 0