clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -UF '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"

#Install commands
$l = 68..90 | % { [char]$_ }
$u = [System.IO.DriveInfo]::GetDrives().Name -replace ':\\',''

$c = Get-WmiObject -Query "SELECT * FROM Win32_Volume WHERE DriveType = 5"
if ($c) {
    Log "Found existing CDROM drive $($c.DriveLetter)"
    $c.DriveLetter = "$($l | ? { $u -notcontains $_ } | select -First 1):"
    Log "Changing CDROM drive letter to $($c.DriveLetter)"
    $null = $c.Put()
    Sleep 1
    $u = [System.IO.DriveInfo]::GetDrives().Name -replace ':\\',''
}

# Handle USB drives to prevent conflicts during MDT installation
$usb = Get-WmiObject -Query "SELECT * FROM Win32_Volume WHERE DriveType = 2 AND DriveLetter IS NOT NULL"
if ($usb) {
    foreach ($usbDrive in $usb) {
        Log "Found USB drive $($usbDrive.DriveLetter)"
        $newLetter = "$($l | ? { $u -notcontains $_ } | select -First 1):"
        $usbDrive.DriveLetter = $newLetter
        Log "Changing USB drive letter to $newLetter"
        $null = $usbDrive.Put()
        Sleep 1
        $u = [System.IO.DriveInfo]::GetDrives().Name -replace ':\\',''
    }
}

Get-Disk | ? { -not $_.IsBoot -and -not $_.IsSystem } | % {
    if ($_.OperationalStatus -eq 'Offline') { Log "Bringing disk $($_.Number) online" ; Set-Disk -Number $_.Number -IsOffline $false }
    if ($_.PartitionStyle -eq 'RAW') {
        Log "Initializing disk $($_.Number) with GPT partition style"
        Initialize-Disk -Number $_.Number -PartitionStyle GPT
        Log "Creating partition on disk $($_.Number) and formatting it"
        New-Partition -DiskNumber $_.Number -UseMaximumSize -AssignDriveLetter | Format-Volume -FileSystem NTFS -NewFileSystemLabel "Data" -Confirm:$false
    }
}

$boot = Get-Disk | ? IsBoot
$free = $boot.Size - (Get-Partition -DiskNumber $boot.Number | Measure-Object Size -Sum).Sum
if ($free -gt 1GB) {
    Log "Creating new partition on boot disk $($boot.Number) with $([math]::Round($free/1GB,1)) GB free"
    $p = New-Partition -DiskNumber $boot.Number -UseMaximumSize -AssignDriveLetter
    Format-Volume -Partition $p -FileSystem NTFS -NewFileSystemLabel "Data" -Confirm:$false
    Log "Created partition $($p.DriveLetter):"
}

if ($c) {
    Log "Found existing CDROM drive $($c.DriveLetter)"
    $c.DriveLetter = "$($l | ? { $u -notcontains $_ } | select -First 1):"
    Log "Changing CDROM drive letter to $($c.DriveLetter)"
    $null = $c.Put()
}

Log "Finished installation"
exit 0