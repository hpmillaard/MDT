clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -U '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
Start "$PSScriptRoot\7Zip32.msi" "/qb! /norestart" -Wait
If ($ENV:PROCESSOR_ARCHITECTURE -match 64){Start "$PSScriptRoot\7Zip64.msi" "/qb! /norestart" -Wait}
reg import "$PSScriptRoot\7Zip.reg"
gci ([environment]::getfolderpath("commonprograms")) | ? name -match "7-Zip" | del -r

change user /execute
Log "Finished installation"
exit 0