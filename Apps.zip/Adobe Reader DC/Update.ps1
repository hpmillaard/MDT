clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
If (!(Test-Path AcroRdrDC1900820071_nl_NL.exe)){Start-BitsTransfer http://ardownload.adobe.com/pub/adobe/reader/win/AcrobatDC/1900820071/AcroRdrDC1900820071_nl_NL.exe $curpath\AcroRdrDC1900820071_nl_NL.exe}
If (!(Test-Path AcroRdrDC1900820071_en_US.exe)){Start-BitsTransfer http://ardownload.adobe.com/pub/adobe/reader/win/AcrobatDC/1900820071/AcroRdrDC1900820071_en_US.exe $curpath\AcroRdrDC1900820071_en_US.exe}
$Link1 = (curl "https://supportdownloads.adobe.com/product.jsp?product=10&platform=Windows").Links | ? outerText -match "Reader DC \(Continuous"
$Link2 = (curl (-Join ('https://supportdownloads.adobe.com/', $Link1[0].href))).Links | ? href -match "thankyou"
$Link3 = (curl (-Join ('https://supportdownloads.adobe.com/', $Link2.href -replace("amp;","")))).Links | ? href -match "msp"
Start-BitsTransfer $Link3.href $curpath\AcroRdrDCUpdate.msp
