clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -U '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

Log "Set Executionpolicy to Bypass"
Set-ExecutionPolicy Bypass -F

Log "Registry Tweaks"
If (Test-Path ..\RegFiles\install.ps1){start powershell ..\RegFiles\install.ps1 -Wait}

Log "Set DPI 100%"
$monitorKeys = dir "HKCU:\Control Panel\Desktop\PerMonitorSettings"
foreach ($monitor in $monitorKeys) {sp $monitor.PSPath -Name "DpiValue" -Value ffffffff -Type DWORD}

Log "Disable Hibernation"
powercfg -H off

Log "Sleep Timeout 0 minutes"
powercfg -X -standby-timeout-ac 0
powercfg -X -standby-timeout-dc 0

Log "Create new powersheme"
powercfg /duplicatescheme SCHEME_BALANCED aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee
powercfg /changename aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee "Optimized" "Optimized powerscheme"
powercfg /s aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee

Log "Disable Sleep"
powercfg -setacvalueindex aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee SUB_SLEEP STANDBYIDLE 0
powercfg -setdcvalueindex aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee SUB_SLEEP STANDBYIDLE 0

Log "Disable Hybrid Sleep"
powercfg -setacvalueindex aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee SUB_SLEEP HYBRIDSLEEP 0
powercfg -setdcvalueindex aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee SUB_SLEEP HYBRIDSLEEP 0

Log "Do not turn off harddisk"
powercfg -setacvalueindex aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee SUB_DISK DISKIDLE 0
powercfg -setdcvalueindex aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee SUB_DISK DISKIDLE 0

Log "Turn off display after 60 min on battery, never on power"
powercfg -setacvalueindex aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee SUB_VIDEO VIDEOIDLE 0
powercfg -setdcvalueindex aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee SUB_VIDEO VIDEOIDLE 3600

Log "Screen Brightness 100%"
powercfg -setacvalueindex aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee SUB_VIDEO VIDEONORMALLEVEL 100
powercfg -setdcvalueindex aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee SUB_VIDEO VIDEONORMALLEVEL 100

Log "Do not require password"
powercfg -setacvalueindex aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee fea3413e-7e05-4911-9a71-700331f1c294 0e796bdb-100d-47d6-a2d5-f7d2daa51f51 0
powercfg -setdcvalueindex aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee fea3413e-7e05-4911-9a71-700331f1c294 0e796bdb-100d-47d6-a2d5-f7d2daa51f51 0

Log "Remove Windows Recovery Environment"
Start "REAgentC" "/disable" -Wait

Log "Enable Windows Remote Management"
Start "winrm" "quickconfig -q" -Wait

Log "Determine Windows Experience Index"
Start "winsat" "formal" -Wait

Log "Set Drive Labels"
Get-Volume C | Set-Volume -NewFileSystemLabel OS
Get-Volume D -EA 0 | Set-Volume -NewFileSystemLabel Data
Get-Volume E -EA 0 | Set-Volume -NewFileSystemLabel Data

Log "Set Computername Label"
(New-Object -Com Shell.Application).NameSpace('::{20D04FE0-3AEA-1069-A2D8-08002B30309D}').Self.Name = $ENV:COMPUTERNAME

Log "Set Network to Private mode"
Set-NetConnectionProfile -NetworkCategory Private

Log "Windows Firewall"
Get-NetFirewallProfile | Set-NetFirewallProfile -Enabled true
$FWRuleGroups = "File and Printer Sharing","Bestands- en printerdeling","Network Discovery","Netwerk detecteren","Performance Logs and Alerts","Remote Administration","Remote Assistance","Hulp op afstand","Remote Desktop","Extern Bureaublad","Remote Desktop - RemoteFX","Extern Bureaublad - RemoteFX","Remote Event Log Management","Extern Event Log-beheer","Remote Scheduled Tasks Management","Extern beheer van geplande taken","Remote Service Management","Extern servicebeheer","Remote Volume Management","Extern volumebeheer","Windows Firewall Remote Management","Extern beheer van Windows Firewall","Windows Management Instrumentation (WMI)","Windows Remote Management"
$FWRuleGroups | % {Get-NetFirewallRule | ? displaygroup -match $_ | Enable-NetFirewallRule}
$NewFWRuleFiles = "$ENV:WINDIR\System32\CCM\clicomp\RemCtrl\RCServer.exe","$ENV:WINDIR\System32\RCAgent.exe","$ENV:WINDIR\SysWOW64\CCM\clicomp\RemCtrl\RCServer.exe","$ENV:WINDIR\SysWOW64\RCAgent.exe"
$NewFWRuleFiles | % {If (Test-Path $_){New-NetFirewallRule -Program $_ -DisplayName (gi $_).name}}

$bg = gci $PSScriptRoot | ? name -match background
If ($bg){Log "Set Background";MD "$ENV:WINDIR\system32\oobe\info\Backgrounds" -EA 0;cp $bg.FullName "$ENV:WINDIR\system32\oobe\info\Backgrounds\backgroundDefault.jpg";sp HKLM:\SOFTWARE\Policies\Microsoft\Windows\System -N UseOEMBackground -V 1 -T DWORD}

$userlogo = gci $PSScriptRoot | ? name -match user
If ($userlogo){Log "Set User Picture";cp $userlogo "$ENV:ProgramData\Microsoft\User Account Pictures\user.bmp";cp $userlogo "$ENV:ProgramData\Microsoft\User Account Pictures\guest.bmp"}

Log "Install .Net 3, Telnet Client and WMIC"
Start "dism.exe" "/online /norestart /Enable-Feature /FeatureName:NetFx3 /FeatureName:TelnetClient" -Wait
Start "dism.exe" "/online /norestart /add-capability /capabilityname:wmic~~~~" -Wait

Log "Remove Windows Features"
Start "dism.exe" "/Online /norestart /Disable-Feature /FeatureName:MSRDC-Infrastructure /FeatureName:Printing-Foundation-Features /FeatureName:FaxServicesClientPackage /FeatureName:WCF-Services45" -Wait

Log "Remove AppxProvisionedPackages"
Get-AppXProvisionedPackage -online | ? {$_.DisplayName -notmatch 'Calculator' -and $_.DisplayName -notmatch 'DesktopAppInstaller' -and $_.DisplayName -notmatch 'Extension' -and $_.DisplayName -notmatch 'Paint' -and $_.DisplayName -notmatch 'Photos' -and $_.DisplayName -notmatch 'QuickAssist' -and $_.DisplayName -notmatch 'ScreenSketch' -and $_.DisplayName -notmatch 'StickyNotes' -and $_.DisplayName -notmatch 'WindowsTerminal' -and $_.DisplayName -notmatch 'WindowsStore'} | Remove-AppXProvisionedPackage -online -EA 0

Log "Remove AppxPackages"
Get-AppxPackage -AllUsers | ? {$_.NonRemovable -eq $False -and $_.Name -notmatch 'Calculator' -and $_.Name -notmatch 'DesktopAppInstaller'  -and $_.Name -notmatch 'Edge' -and $_.Name -notmatch 'Extension' -and $_.Name -notmatch 'NET.Native' -and $_.Name -notmatch 'Notepad' -and $_.Name -notmatch 'Paint' -and $_.Name -notmatch 'Photos' -and $_.Name -notmatch 'QuickAssist' -and $_.Name -notmatch 'Runtime' -and $_.Name -notmatch 'ScreenSketch' -and $_.Name -notmatch 'StickyNotes' -and $_.Name -notmatch 'Todos' -and $_.Name -notmatch 'UI.Xaml' -and $_.Name -notmatch 'VCLibs' -and $_.Name -notmatch 'WindowsStore' -and $_.Name -notmatch 'WindowsTerminal' -and $_.Name -notmatch 'Winget' -and $_.Name -notmatch 'WinJS'} | Remove-AppxPackage -EA 0

Log "Trust PSGallery"
Install-PackageProvider -Name NuGet -Force -Confirm:$false
Set-PSRepository -Name PSGallery -InstallationPolicy Trusted
Install-Script -Name Get-Parameter -Force -Confirm:$false

change user /execute
Log "Finished installation"
exit 0