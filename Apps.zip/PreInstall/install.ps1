clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -UF '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

Log "Set Executionpolicy to Bypass"
Set-ExecutionPolicy Bypass -F

If (Test-Path "..\RegFiles\install.ps1"){Log "Registry Tweaks";Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$($PSScriptRoot)\..\regfiles\install.ps1`"" -WindowStyle Hidden -Verb RunAs -Wait}
If (Test-Path "..\Create Partitions\install.ps1"){Log "Create Partitions";& "..\Create Partitions\install.ps1"}

Log "Set Drive Labels"
Get-Volume C | Set-Volume -NewFileSystemLabel OS

Log "Set Computername Label"
(New-Object -Com Shell.Application).NameSpace('::{20D04FE0-3AEA-1069-A2D8-08002B30309D}').Self.Name = $ENV:COMPUTERNAME

Log "Disable Hibernation"
powercfg -H off

Log "Sleep Timeout 0 minutes"
powercfg -X -standby-timeout-ac 0
powercfg -X -standby-timeout-dc 0

Log "Create new powerscheme"
$Schema = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
$null = powercfg /duplicatescheme SCHEME_BALANCED $Schema
Log "Change powersheme name"
powercfg /changename $Schema "Optimized" "Optimized powerscheme"
Log "Activate powersheme"
powercfg /s $Schema

Log "Disable Sleep"
powercfg -setacvalueindex $Schema SUB_SLEEP STANDBYIDLE 0
powercfg -setdcvalueindex $Schema SUB_SLEEP STANDBYIDLE 0

Log "Disable Hybrid Sleep"
powercfg -setacvalueindex $Schema SUB_SLEEP HYBRIDSLEEP 0
powercfg -setdcvalueindex $Schema SUB_SLEEP HYBRIDSLEEP 0

Log "Do not turn off harddisk"
powercfg -setacvalueindex $Schema SUB_DISK DISKIDLE 0
powercfg -setdcvalueindex $Schema SUB_DISK DISKIDLE 0

Log "Turn off display after 60 min on battery, never on power"
powercfg -setacvalueindex $Schema SUB_VIDEO VIDEOIDLE 0
powercfg -setdcvalueindex $Schema SUB_VIDEO VIDEOIDLE 3600

Log "Screen Brightness 100%"
powercfg -setacvalueindex $Schema SUB_VIDEO VIDEONORMALLEVEL 100
powercfg -setdcvalueindex $Schema SUB_VIDEO VIDEONORMALLEVEL 100

Log "Do not require password"
powercfg -setacvalueindex $Schema fea3413e-7e05-4911-9a71-700331f1c294 0e796bdb-100d-47d6-a2d5-f7d2daa51f51 0
powercfg -setdcvalueindex $Schema fea3413e-7e05-4911-9a71-700331f1c294 0e796bdb-100d-47d6-a2d5-f7d2daa51f51 0

Log "Remove Windows Recovery Environment"
Start "REAgentC" "/disable" -Wait

Log "Enable Windows Remote Management"
Start "winrm" "quickconfig -q" -Wait

Log "Determine Windows Experience Index"
Start "winsat" "formal" -Wait

Log "Set Network to Private mode"
Set-NetConnectionProfile -NetworkCategory Private

Log "Windows Firewall"
Get-NetFirewallProfile | Set-NetFirewallProfile -Enabled true
$FWRuleGroups = "File and Printer Sharing","Bestands- en printerdeling","Network Discovery","Netwerk detecteren","Performance Logs and Alerts","Remote Administration","Remote Assistance","Hulp op afstand","Remote Desktop","Extern Bureaublad","Remote Desktop - RemoteFX","Extern Bureaublad - RemoteFX","Remote Event Log Management","Extern Event Log-beheer","Remote Scheduled Tasks Management","Extern beheer van geplande taken","Remote Service Management","Extern servicebeheer","Remote Volume Management","Extern volumebeheer","Windows Firewall Remote Management","Extern beheer van Windows Firewall","Windows Management Instrumentation (WMI)","Windows Remote Management"
$FWRuleGroups | % {Get-NetFirewallRule | ? displaygroup -match $_ | Enable-NetFirewallRule}
$NewFWRuleFiles = "$ENV:WINDIR\System32\CCM\clicomp\RemCtrl\RCServer.exe","$ENV:WINDIR\System32\RCAgent.exe","$ENV:WINDIR\SysWOW64\CCM\clicomp\RemCtrl\RCServer.exe","$ENV:WINDIR\SysWOW64\RCAgent.exe"
$NewFWRuleFiles | % {If (Test-Path $_){New-NetFirewallRule -Program $_ -DisplayName (gi $_).name}}

$bg = dir $PSScriptRoot | ? name -match background
If ($bg){Log "Set Background";MD "$ENV:WINDIR\system32\oobe\info\Backgrounds" -EA 0;cp $bg.FullName "$ENV:WINDIR\system32\oobe\info\Backgrounds\backgroundDefault.jpg";sp HKLM:\SOFTWARE\Policies\Microsoft\Windows\System -N UseOEMBackground -V 1 -T DWORD}

$userlogo = dir $PSScriptRoot | ? name -match user
If ($userlogo){Log "Set User Picture";cp $userlogo "$ENV:ProgramData\Microsoft\User Account Pictures\user.bmp";cp $userlogo "$ENV:ProgramData\Microsoft\User Account Pictures\guest.bmp"}

Log "Trust PSGallery"
$null = Install-PackageProvider NuGet -Force -Confirm:$false
$null = Set-PSRepository PSGallery -InstallationPolicy Trusted
$null = Install-Script Get-Parameter -Force -Confirm:$false

# Only run the next commands on Client OS
If ((Get-CimInstance Win32_OperatingSystem).caption -notmatch "server"){
    $FeaturesToEnable = "NetFx3","TelnetClient"
    foreach ($Feature in $FeaturesToEnable) {Log "Install Windows Feature $Feature";$null = dism /Online /NoRestart /Enable-Feature /FeatureName:$Feature}

    $FeaturesToDisable = "MSRDC-Infrastructure", "Printing-Foundation-Features", "FaxServicesClientPackage", "WCF-Services45"
    foreach ($Feature in $FeaturesToDisable) {Log "Remove Windows Feature $Feature";$null = dism /Online /NoRestart /Disable-Feature /FeatureName:$Feature}

    $Remove = 'Alarms|Bing|CrossDevice|Gaming|Family|Solitaire|xbox|YourPhone|Zune'
    Log "Remove Provisioned Appx Packages"
    Get-AppxProvisionedPackage -Online | ? {$_.DisplayName -match $Remove} | Remove-AppxProvisionedPackage -Online
    Log "Remove Installed Appx Packages (all users)"
    Get-AppxPackage -AllUsers | ? {-not $_.NonRemovable -and $_.Name -match $Remove} | Remove-AppxPackage

    Log "Install WMIC"
    dism /Online /NoRestart /Add-Capability /capabilityname:wmic~~~~
}

change user /execute
Log "Finished installation"
exit 0