clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
$URL = "https://download.filezilla-project.org/client/"
$Links = (curl $URL).Links
curl ($URL + ($Links | where {$_.href -match "win32-setup.exe" -and $_.href -notmatch "latest"} | Select-Object -Last 1).href) -OutFile $curpath\FileZilla-x32.exe
curl ($URL + ($Links | where {$_.href -match "win64-setup.exe" -and $_.href -notmatch "latest"} | Select-Object -Last 1).href) -OutFile $curpath\FileZilla-x64.exe
