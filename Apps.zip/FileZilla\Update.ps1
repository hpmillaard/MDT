clear
$host.ui.RawUI.WindowTitle = (gi $PSScriptRoot).Name
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$URL = "https://download.filezilla-project.org/client/"
$Agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36"
$Links = (curl $URL -UseBasicParsing -UserAgent $Agent).Links
curl ($URL + ($Links | where {$_.href -match "win32-setup.exe" -and $_.href -notmatch "latest"} | Select-Object -Last 1).href) -UserAgent $Agent -OutFile $PSScriptRoot\FileZilla-x32.exe
curl ($URL + ($Links | where {$_.href -match "win64-setup.exe" -and $_.href -notmatch "latest"} | Select-Object -Last 1).href) -UserAgent $Agent -OutFile $PSScriptRoot\FileZilla-x64.exe
