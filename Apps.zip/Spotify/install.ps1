clear
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -UF '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
winget install 9NCBCSZSJRSB -e --accept-source-agreements --accept-package-agreements
rp "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\" Spotify -EA 0

change user /execute
Log "Finished installation"
exit 0