clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -UF '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
winget install WinSCP.WinSCP -e --accept-source-agreements --scope machine

gci ([environment]::getfolderpath("desktop")) | ? name -match "WinSCP" | del -EA 0
gci ([environment]::getfolderpath("commondesktop")) | ? name -match "WinSCP" | del -EA 0

change user /execute
Log "Finished installation"
exit 0