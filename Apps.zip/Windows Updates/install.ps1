clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -U '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
$ServiceManager = New-Object -ComObject "Microsoft.Update.ServiceManager"
$ServiceManager.ClientApplicationID = "My App"
$NewUpdateService = $ServiceManager.AddService2("7971f918-a847-4430-9279-4a52d1efe18d",7,"")

If (Test-Path "$ENV:SCRIPTROOT\ZTIWindowsUpdate.wsf"){
	start cscript "$ENV:SCRIPTROOT\ZTIWindowsUpdate.wsf" -Wait
}Else{
	[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
	Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -EA 0
	Set-PSRepository -InstallationPolicy Trusted -Name PSGallery -EA 0
	Install-Script -Name PSWindowsUpdate -Force
	Import-Module PSWindowsUpdate
	Get-WindowsUpdate -MicrosoftUpdate -AcceptAll -Download -Install -IgnoreReboot -NotCategory Drivers
}

change user /execute
Log "Finished installation"
exit 0