clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
Start-BitsTransfer https://g.msn.com/1rewlive5skydrive/skydrivesetup $curpath\OneDriveSetupWeb.exe
$CurrentVersion = (get-item $curpath\OneDriveSetup.exe).VersionInfo.FileVersion
$WebVersion = (get-item $curpath\OneDriveSetupWeb.exe).VersionInfo.FileVersion
$LocalVersion = (get-item $ENV:LOCALAPPDATA\Microsoft\OneDrive\Update\OneDriveSetup.exe).VersionInfo.FileVersion
If ($WebVersion -gt $CurrentVersion) {
	Write-Host "Webversion is newer, keep webversion"
	del $curpath\OneDriveSetup.exe
	ren $curpath\OneDriveSetupWeb.exe $curpath\OneDriveSetup.exe
} Else {
	Write-Host "Webversion is older, remove webversion"
	del $curpath\OneDriveSetupWeb.exe
}
If ($LocalVersion -gt $CurrentVersion) {
	Write-Host "Local version is newer, copy Local version"
	copy $ENV:LOCALAPPDATA\Microsoft\OneDrive\Update\OneDriveSetup.exe $curpath\OneDriveSetup.exe -Force
}
