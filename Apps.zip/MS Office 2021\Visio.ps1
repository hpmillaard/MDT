clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSCommandPath).BaseName + " - " + (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -U '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
$c = "$ENV:TEMP\Config.xml"
ac $c "<Configuration>"
ac $c "  <Add OfficeClientEdition=""32"" Channel=""PerpetualVL2021"" SourcePath=""%TEMP%\O2021"" AllowCdnFallback=""TRUE"" ForceUpgrade=""TRUE"">"
ac $c "    <Product ID=""VisioPro2021Volume"" PIDKEY=""KNH8D-FGHT4-T8RK3-CTDYJ-K2HT4"">"
ac $c "      <Language ID=""MatchOS"" Fallback=""en-us"" />"
ac $c "      <Language ID=""nl-nl"" />"
ac $c "    </Product>"
ac $c "  </Add>"
ac $c "  <Property Name=""SharedComputerLicensing"" Value=""0"" />"
ac $c "  <Property Name=""PinIconsToTaskbar"" Value=""FALSE"" />"
ac $c "  <Property Name=""SCLCacheOverride"" Value=""0"" />"
ac $c "  <Updates Enabled=""TRUE"" />"
ac $c "  <RemoveMSI />"
ac $c "  <Display Level=""None"" AcceptEULA=""TRUE"" />"
ac $c "</Configuration>"

Start "$PSScriptRoot\setup.exe" "/download $c" -Wait
Start "$PSScriptRoot\setup.exe" "/configure $c" -Wait

gi $ENV:TEMP\O2021 | del -r
gi $ENV:TEMP\config.xml | del

change user /execute
Log "Finished installation"
exit 0