clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -UF '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
winget install Adobe.Acrobat.Reader.32-bit -e --accept-source-agreements --scope machine

gci ([environment]::getfolderpath("desktop")) | ? name -match "Acrobat Reader" | del -EA 0
gci ([environment]::getfolderpath("commondesktop")) | ? name -match "Acrobat Reader" | del -EA 0

reg import "$PSScriptRoot\adobe.reg"
sc.exe delete AdobeARMservice
schtasks /delete /TN "Adobe Acrobat Update Task" /F

If ($ENV:PROCESSOR_ARCHITECTURE -match 64){$Prog = ${ENV:ProgramFiles(x86)}}Else{$Prog = $ENV:ProgramFiles}
If (Test-Path "$PSScriptRoot\HideMenu.js"){copy "$PSScriptRoot\HideMenus.js" "$Prog\Adobe\Acrobat Reader DC\Reader\Javascripts\HideMenus.js" -Force}

change user /execute
Log "Finished installation"
exit 0