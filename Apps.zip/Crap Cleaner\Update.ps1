clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name

taskkill /f /im ccleaner.exe
taskkill /f /im ccleaner64.exe

Write-Host "Download CCleaner Portable" -foregroundcolor Green
Start-BitsTransfer ((curl 'https://www.ccleaner.com/nl-nl/ccleaner/download/portable' -UseBasicParsing).Links | ? href -match ".zip").href $curpath\CCleaner.zip
If ((Get-Item $curpath\CCleaner.zip).length -gt 100kb) {Expand-Archive $curpath\CCleaner.zip -Destination $curpath -Force} Else {del $curpath\CCleaner.zip}

Write-Host "Download CCleaner Slim" -foregroundcolor Green
Start-BitsTransfer ((curl 'https://www.ccleaner.com/nl-nl/ccleaner/download/slim' -UseBasicParsing).Links | ? href -match "_RELEASE").href $curpath\ccsetup_slim_new.exe
If ((Get-Item $curpath\ccsetup_slim_new.exe).length -gt 100kb) {del $curpath\ccsetup_slim.exe;ren $curpath\ccsetup_slim_new.exe $curpath\ccsetup_slim.exe -Force} Else {del $curpath\ccsetup_slim_new.exe}
rd $curpath\data -Recurse -Force -ErrorAction SilentlyContinue
rd $curpath\log -Recurse -Force -ErrorAction SilentlyContinue
rd $curpath\lang -Recurse -Force -ErrorAction SilentlyContinue
rd $curpath\setup -Recurse -Force -ErrorAction SilentlyContinue
rd $curpath\temp_ccupdate -Recurse -Force -ErrorAction SilentlyContinue
#rd $curpath\x86 -Recurse -Force -ErrorAction SilentlyContinue
#rd $curpath\x64 -Recurse -Force -ErrorAction SilentlyContinue
del $curpath\License.txt -ErrorAction SilentlyContinue
del $curpath\portable.dat -ErrorAction SilentlyContinue
del $curpath\CCleaner.zip -ErrorAction SilentlyContinue
del $curpath\CCleaner*.dll -ErrorAction SilentlyContinue
del $curpath\gcapi*.dll -ErrorAction SilentlyContinue
del $curpath\*conflict* -ErrorAction SilentlyContinue
