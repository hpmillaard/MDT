clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name

Start-BitsTransfer ((curl 'https://www.ccleaner.com/ccleaner/download/slim').Links | ? innerhtml -match "start").href $curpath\ccsetup_slim_new.exe
If ((Get-Item $curpath\ccsetup_slim_new.exe).length -gt 100kb) {del $curpath\ccsetup_slim.exe;ren $curpath\ccsetup_slim_new.exe $curpath\ccsetup_slim.exe -Force} Else {del $curpath\ccsetup_slim_new.exe}
