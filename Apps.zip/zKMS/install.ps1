clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -U '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

# Install commands
$ProgressPreference='SilentlyContinue'
$KMSList = "kms7.msguides.com", "kms8.msguides.com", "kms9.msguides.com", "kms.digiboy.ir", "kms.chinancce.com", "kms.ddns.net", "franklv.ddns.net", "k.zpale.com", "kms789.com", "kms.axians.nl"
ForEach ($KMS in $KMSList) {If ((Test-NetConnection -ComputerName $KMS -Port 1688 -WarningAction SilentlyContinue).TcpTestSucceeded -eq $True) {Write-Host KMS Host found on $KMS -F Green;Break}}

# Activate Windows
cscript $ENV:WINDIR\System32\slmgr.vbs /ckms
cscript $ENV:WINDIR\System32\slmgr.vbs /skms $KMS
cscript $ENV:WINDIR\System32\slmgr.vbs /ato

# Activate Office
ForEach ($n in (14..16)) {If (Test-Path "${ENV:ProgramFiles(x86)}\Microsoft Office\Office$n\ospp.vbs") {$V = $n; $x86 = $True}}
ForEach ($n in (14..16)) {If (Test-Path "$ENV:ProgramFiles\Microsoft Office\Office$n\ospp.vbs") {$V = $n; $x64 = $True}}
If ($x86) {
	cscript "${ENV:ProgramFiles(x86)}\Microsoft Office\Office$V\ospp.vbs" /remhst
	cscript "${ENV:ProgramFiles(x86)}\Microsoft Office\Office$V\ospp.vbs" /sethst:$KMS
	cscript "${ENV:ProgramFiles(x86)}\Microsoft Office\Office$V\ospp.vbs" /act
	clear
	cscript "${ENV:ProgramFiles(x86)}\Microsoft Office\Office$V\ospp.vbs" /dstatus
}
If ($x64) {
	cscript "$ENV:ProgramFiles\Microsoft Office\Office$V\ospp.vbs" /remhst
	cscript "$ENV:ProgramFiles\Microsoft Office\Office$V\ospp.vbs" /sethst:$KMS
	cscript "$ENV:ProgramFiles\Microsoft Office\Office$V\ospp.vbs" /act
	clear
	cscript "$ENV:ProgramFiles\Microsoft Office\Office$V\ospp.vbs" /dstatus
}
cscript $ENV:WINDIR\System32\slmgr.vbs /dlv

change user /execute
Log "Finished installation"
exit 0