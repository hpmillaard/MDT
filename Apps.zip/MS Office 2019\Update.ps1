clear
$host.ui.RawUI.WindowTitle = (Get-Item $PSScriptRoot).Name
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Start-BitsTransfer "https://officecdn.microsoft.com/pr/wsus/setup.exe" "$PSScriptRoot\setup.exe"