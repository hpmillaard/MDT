clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
curl ((curl https://www.microsoft.com/en-us/download/confirmation.aspx?id=49117 -UseBasicParsing).Links | ? {$_.outerHTML -match "manually"}).href -UseBasicParsing -OutFile $curpath\officedeploymenttool.exe
& $curpath\officedeploymenttool.exe /quiet /extract:$curpath
start-sleep -s 5
del $curpath\officedeploymenttool.exe -force
del $curpath\configuration-*.xml -force
