clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = "UpdateAtStartup"
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -UF '%a %d-%m-%G %X') $title - $content"}
Log "Script started"
change user /install

function Update-EveryModule {
    [cmdletbinding(SupportsShouldProcess = $true)]
    param (
        [parameter()]
        [array]$ExcludedModules = @(),
        [parameter()]
        [switch]$SkipMajorVersion,
        [parameter()]
        [switch]$KeepOldModuleVersions,
        [parameter()]
        [array]$ExcludedModulesforRemoval = @("")
    )
    # Get all installed modules that have a newer version available
    Write-Verbose "Checking all installed modules for available updates."
    $CurrentModules = Get-InstalledModule | Where-Object { $ExcludedModules -notcontains $_.Name -and $_.repository -eq "PSGallery" }

    # Walk through the Installed modules and check if there is a newer version
    $CurrentModules | ForEach-Object {
        Write-Verbose "Checking $($_.Name)"
        Try {
            $GalleryModule = Find-Module -Name $_.Name -Repository PSGallery -ErrorAction Stop
        }
        Catch {
            Write-Error "Module $($_.Name) not found in gallery $_"
            $GalleryModule = $null
        }
        if ($GalleryModule.Version -gt $_.Version) {
            if ($SkipMajorVersion -and $GalleryModule.Version.Split('.')[0] -gt $_.Version.Split('.')[0]) {
                Write-Warning "Skipping major version update for module $($_.Name). Galleryversion: $($GalleryModule.Version), local version $($_.Version)"
            }
            else {
                Write-Verbose "$($_.Name) will be updated. Galleryversion: $($GalleryModule.Version), local version $($_.Version)"
                try {
                    if ($PSCmdlet.ShouldProcess(
                        ("Module {0} will be updated to version {1}" -f $_.Name, $GalleryModule.Version),$_.Name,"Update-Module")
                    ) {
                        $OldVersion = $_.Version
                        Update-Module $_.Name -ErrorAction Stop -Force
                        $NewVersion = (Get-InstalledModule -Name $_.Name).Version
                        Log "Module $($_.Name) updated: $OldVersion → $NewVersion"
                    }
                }
                Catch {
                    Write-Error "$($_.Name) failed: $_ "
                    continue
                }
                if ($KeepOldModuleVersions -ne $true) {
                    Write-Verbose "Removing old module $($_.Name)"
                    if ($ExcludedModulesforRemoval -contains $_.Name) {
                        Write-Verbose "$($allversions.count) versions of this module found [ $($module.name) ]"
                        Write-Verbose "Please check this manually as removing the module can cause instabillity."
                    }
                    else {
                        try {
                            if ($PSCmdlet.ShouldProcess(("Old versions will be uninstalled for module {0}" -f $_.Name),$_.Name,"Uninstall-Module")) {
                                Get-InstalledModule -Name $_.Name -AllVersions | Where-Object { $_.version -ne $GalleryModule.Version } | Uninstall-Module -Force -ErrorAction Stop
                                Write-Verbose "Old versions of $($_.Name) have been removed"
                            }
                        }
                        catch {
                            Write-Error "Uninstalling old module $($_.Name) failed: $_"
                        }
                    }
                }
            }
        }
        elseif ($null -ne $GalleryModule) {
            Write-Verbose "$($_.Name) is up to date"
        }
    }
}

function Update-Winget {
    param([switch]$ScopeMachine)

    $scope = if ($ScopeMachine) { @('--scope', 'machine') } else { @() }
    $scopeName = if ($ScopeMachine) { "machine" } else { "user" }
    Log "Check Winget Updates ($scopeName)."

    $pre = [IO.Path]::GetTempFileName() + '.json'
    $post = [IO.Path]::GetTempFileName() + '.json'

    $null = winget export --include-versions -o $pre @scope
    $before = (Get-Content $pre | ConvertFrom-Json).Sources.Packages | Group-Object PackageIdentifier -AsHashTable -AsString

    $durations = @{}

    foreach ($pkg in $before.Values) {
        $id = $pkg.PackageIdentifier; $t = Get-Date
	    Write-Host "Checking for updates on: " -F Green -NoNewline; Write-Host "$id" -F Yellow
        try {
            $null = winget upgrade -e --id $id --accept-source-agreements --accept-package-agreements -h @scope 2>&1
            if ($LASTEXITCODE -ne 0 -and ($error[0] -match 'install technology is different')) {
                $null = winget uninstall -e --id $id @scope 2>&1
                $null = winget install  -e --id $id --accept-source-agreements --accept-package-agreements -h @scope 2>&1
            }
        }
        catch { Log "$id update gefaald: $_" }
        $durations[$id] = New-TimeSpan $t (Get-Date)
    }

    $null = winget export --include-versions -o $post @scope
    $after = (Get-Content $post | ConvertFrom-Json).Sources.Packages | Group-Object PackageIdentifier -AsHashTable -AsString

    $updates = 0
    foreach ($id in $before.Keys) {
        $old = $before[$id].Version; $new = $after[$id].Version
        if ($old -ne $new -and $durations.ContainsKey($id)) {
            Log "$id $old → $new update took $($durations[$id])"
            $updates++
        }
    }
    if ($updates -eq 0) {Log "No updates found."} else { Log "Updated $updates packages" }
    Remove-Item $pre, $post -Force
}

$IsSystem = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value -eq "S-1-5-18"
Update-Winget -ScopeMachine:$IsSystem

Log "Update Store apps"
(Get-WMIObject MDM_EnterpriseModernAppManagement_AppManagement01 -Namespace root\cimv2\mdm\dmmap).UpdateScanMethod()

Log "Update PowerShell Modules"
Update-EveryModule

Log "Update PowerShell Help"
Update-Help -EA 0

change user /execute
Log "Script Finished"
exit 0