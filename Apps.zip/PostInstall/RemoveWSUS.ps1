if (Test-Path 'C:\MININT') { exit 0 }
$SecFile = "$ENV:Temp\security.inf"
$DBFile = "$ENV:Temp\temp.db"
$ScriptPath = $MyInvocation.MyCommand.Path
@"
[Unicode]
Unicode=yes
[Version]
signature="\$CHICAGO$"
Revision=1
[Registry Keys]
"HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows\WindowsUpdate",0,"D:PAR(A;CI;KA;;;BA)(A;CIIO;KA;;;CO)(A;CI;KA;;;SY)(A;CI;KR;;;BU)"
"@ | sc $SecFile -Encoding ASCII
Start secedit.exe "/configure", "/cfg", "`"$SecFile`"", "/db", "`"$DBFile`"", "/overwrite", "/areas", "regkeys", "/quiet" -Wait -NoNewWindow
del 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Recurse -Force -EA 0
del 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Recurse -Force -EA 0
Restart-Service wuauserv -EA 0
schtasks /Delete /TN "RemoveWSUS" /F | Out-Null
del $SecFile -Force -EA 0
del $DBFile -Force -EA 0
del $ScriptPath -Force -EA 0
exit 0