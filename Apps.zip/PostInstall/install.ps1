clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -UF '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

$CC = (Join-Path (gi $PSScriptRoot).Parent.FullName "Crap Cleaner\run.ps1")
If (Test-Path $CC){Log "Run Crap Cleaner";Start "powershell" "-executionpolicy bypass -file ""$CC""" -Wait}

If (Test-Path "..\Windows Updates\install.ps1"){Log "Windows Updates";start powershell "..\Windows Updates\install.ps1" -Wait}

Log "Create scheduled task to run UpdatesAtStartup.ps1 for Administrators"
copy "$PSScriptRoot\UpdateAtStartup.ps1" "C:\Windows" -Force
Register-ScheduledTask "UpdateAtLogon" -InputObject (New-ScheduledTask (New-ScheduledTaskAction "powershell.exe" "-NoProfile -WindowStyle Minimized -ExecutionPolicy Bypass -File C:\Windows\UpdateAtStartup.ps1") (New-ScheduledTaskTrigger -AtLogon) -Principal (New-ScheduledTaskPrincipal -G "Administrators" Highest)) -Force
$xml = (Export-ScheduledTask -TaskName "UpdateAtLogon") -replace '(?=</Triggers>)', "    <SessionStateChangeTrigger>`n      <StateChange>SessionUnlock</StateChange>`n    </SessionStateChangeTrigger>`n"
Register-ScheduledTask -TaskName "UpdateAtLogon" -Xml $xml -Force

Log "Create scheduled task to run UpdatesAtStartup.ps1 for SYSTEM"
Register-ScheduledTask "UpdateAtStartup" -InputObject (New-ScheduledTask (New-ScheduledTaskAction "powershell.exe" "-NoProfile -ExecutionPolicy Bypass -File C:\Windows\UpdateAtStartUp.ps1") (New-ScheduledTaskTrigger -AtStartup) -Principal (New-ScheduledTaskPrincipal "NT AUTHORITY\SYSTEM" ServiceAccount Highest)) -Force

Log "Set File associations"
Start "dism" "/Online /Import-DefaultAppAssociations:$PSScriptRoot\DefaultApps.xml" -Wait

Log "Set Start Menu Layout"
If ((gwmi win32_operatingsystem).BuildNumber -lt 21999) {Import-StartLayout "$PSScriptRoot\StartMenuW10.xml" -MountPath $ENV:SystemDrive\}

Log "Cleanup Start Menu"
dir "$ENV:LocalAppData\Microsoft\Windows" | ? name -match itemdata | del

if ((New-Object -Com Microsoft.SMS.TSEnvironment).GetVariables() -contains 'WSUSServer') {
    Log "Reset WSUS if a WSUS server was used during MDT with scheduled task at startup"
    copy "$PSScriptRoot\RemoveWSUS.ps1" "$ENV:Programdata\RemoveWSUS.ps1" -Force
    $null = schtasks /create /RU SYSTEM /SC ONSTART /TN RemoveWSUS /TR "powershell -executionpolicy bypass -file `"$env:ProgramData\RemoveWSUS.ps1`"" /F
}

If (Test-Path $CC){Log "Run Crap Cleaner";Start powershell "-executionpolicy bypass -file ""$CC""" -Wait}

change user /execute
Log "Finished installation"
exit 0