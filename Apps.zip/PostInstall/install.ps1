clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -U '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

Log "Run Crap Cleaner"
$CC = (Join-Path (gi $PSScriptRoot).Parent.FullName "Crap Cleaner\run.ps1");If (Test-Path $CC){Start "powershell" "-executionpolicy bypass -file ""$CC""" -Wait}

Log "Update Store apps"
(Get-WMIObject MDM_EnterpriseModernAppManagement_AppManagement01 -Namespace root\cimv2\mdm\dmmap).UpdateScanMethod()

Log "Update Powershell Help"
Update-Help -EA 0

Log "Update PowerShell Modules"
Get-Module -ListAvailable | Update-Module -Force -EA 0

Log "Update winget apps"
winget upgrade --all

Log "Create scheduled task to run Updates at startup"
schtasks /create /RU SYSTEM /SC ONSTART /TN Update /RL HIGHEST /F /TR "powershell -NoProfile -ExecutionPolicy Bypass -Command \"winget update --all;Get-Module -ListAvailable | Update-Module -Force -EA 0;(Get-WMIObject MDM_EnterpriseModernAppManagement_AppManagement01 -Namespace root\cimv2\mdm\dmmap).UpdateScanMethod();Update-Help -EA 0\""

Log "Set File associations"
Start "dism" "/Online /Import-DefaultAppAssociations:$PSScriptRoot\DefaultApps.xml" -Wait

Log "Set Start Menu Layout"
If ((gwmi win32_operatingsystem).BuildNumber -lt 21999) {Import-StartLayout "$PSScriptRoot\StartMenuW10.xml" -MountPath $ENV:SystemDrive\}

Log "Cleanup Start Menu"
gci "$ENV:LocalAppData\Microsoft\Windows" | ? name -match itemdata | del

Log "Reset WSUS if used during MDT with scheduled task at startup"
cp "$PSScriptRoot\Remove WSUS.vbs" "$ENV:Temp\RemoveWSUS.vbs" -force
Start schtasks "/create /RU """" /SC ONSTART /TN RemoveWSUS /TR ""$ENV:TEMP\RemoveWSUS.vbs"" /F" -Wait

Log "Run Crap Cleaner"
If (Test-Path $CC){Start powershell "-executionpolicy bypass -file ""$CC""" -Wait}

change user /execute
Log "Finished installation"
exit 0