clear
$host.ui.RawUI.WindowTitle = (gi $PSScriptRoot).Name
Start-BitsTransfer ((curl https://sourceforge.net/projects/winscp/best_release.json | convertfrom-json).release.url).replace("/download","") "$PSScriptRoot\WinSCP-Setup.exe"
