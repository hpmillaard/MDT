clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Function Get-RedirectedUrl {
	Param ([Parameter(Mandatory=$true)][String]$URL)
	$request = [System.Net.WebRequest]::Create($url)
	$request.AllowAutoRedirect=$false
	$response=$request.GetResponse()
	$response.GetResponseHeader("Location")
}
$exeLink = curl 'https://sourceforge.net/projects/winscp/files/latest/download' -MaximumRedirection 0 -UserAgent [Microsoft.PowerShell.Commands.PSUserAgent]::FireFox -ErrorAction SilentlyContinue
Start-BitsTransfer (Get-RedirectedUrl $exeLink.Headers.Location) $curpath\WinSCP-Setup.exe
