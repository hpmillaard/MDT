clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
Start-BitsTransfer ((curl https://sourceforge.net/projects/winscp/best_release.json | convertfrom-json).release.url).replace("/download","") "$curpath\WinSCP-Setup.exe"
