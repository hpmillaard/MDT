clear
$host.ui.RawUI.WindowTitle = (Get-Item $PSScriptRoot).Name
Start-BitsTransfer ((curl https://sourceforge.net/projects/winscp/best_release.json | convertfrom-json).release.url).replace("/download","") "$PSScriptRoot\WinSCP-Setup.exe"
