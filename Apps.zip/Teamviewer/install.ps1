clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -UF '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
winget install TeamViewer.TeamViewer -e --accept-source-agreements --scope machine

gci ([environment]::getfolderpath("desktop")) | ? name -match "TeamViewer" | del -EA 0
gci ([environment]::getfolderpath("commondesktop")) | ? name -match "TeamViewer" | del -EA 0

md HKCU:\SOFTWARE\TeamViewer -EA 0
sp HKCU:\SOFTWARE\TeamViewer ConfigurationCompanionDockEnabled 1 -t DWord -Fo
sp HKCU:\SOFTWARE\TeamViewer ConfigurationCoPilotEnabled 1 -t DWord -Fo
sp HKCU:\SOFTWARE\TeamViewer ConfigurationOneUIOptInEnabled 1 -t DWord -Fo
sp HKCU:\SOFTWARE\TeamViewer ConfigurationRMAssetReportingEnabled 1 -t DWord -Fo
sp HKCU:\SOFTWARE\TeamViewer ConfigurationSessionSummaryBetaLicenseFlag 1 -t DWord -Fo
sp HKCU:\SOFTWARE\TeamViewer ConfigurationSessionSummaryEnabled 1 -t DWord -Fo
sp HKCU:\SOFTWARE\TeamViewer ConfigurationTryOneUIPhase 5 -t DWord -Fo
sp HKCU:\SOFTWARE\TeamViewer LastSelectedTabInTVR 4 -t DWord -Fo
sp HKCU:\SOFTWARE\TeamViewer IntroShown 1 -t DWord -Fo
sp HKCU:\SOFTWARE\TeamViewer MinimizeToTray 1 -t DWord -Fo
sp HKCU:\SOFTWARE\TeamViewer PilotTabWasEnabled 1 -t DWord -Fo
sp HKCU:\SOFTWARE\TeamViewer Remote_RemoteCursor 1 -t DWord -Fo
sp HKCU:\SOFTWARE\TeamViewer TVOne_PersistentUIState '{"betaIntroShown":true,"devicesViewType":"Advanced","lastSelectedTab":"DeviceAndContactList","theme":"Dark"}' -Fo
sp HKCU:\SOFTWARE\TeamViewer UIVersion 4 -t DWord -Fo

md HKCU:\SOFTWARE\TeamViewer\MsgBoxDontShow -EA 0
sp HKCU:\SOFTWARE\TeamViewer\MsgBoxDontShow QuitWithAutostart 1 -t DWord -Fo

md HKLM:\SOFTWARE\TeamViewer -EA 0
md HKLM:\SOFTWARE\TeamViewer\DefaultSettings -EA 0
sp HKLM:\SOFTWARE\TeamViewer\DefaultSettings Remote_RemoteCursor 1 -t DWord -Fo

change user /execute
Log "Finished installation"
exit 0