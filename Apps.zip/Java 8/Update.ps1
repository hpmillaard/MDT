clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
#[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
#$Links = (Invoke-WebRequest http://www.java.com/en/download/manual.jsp -UserAgent 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:72.0) Gecko/20100101 Firefox/72.0').Links
#Start-BitsTransfer ($Links | ? innerHTML -like "Windows Offline").href $curpath\jre8.exe
#Start-BitsTransfer ($Links | ? innerHTML -like "Windows Offline (64-bit)").href $curpath\jre8-x64.exe
Start-BitsTransfer https://javadl.oracle.com/webapps/download/AutoDL?BundleId=244066_89d678f2be164786b292527658ca1605 $curpath\jre8.exe
Start-BitsTransfer https://javadl.oracle.com/webapps/download/AutoDL?BundleId=244068_89d678f2be164786b292527658ca1605 $curpath\jre8-x64.exe

# Comment the next line to create MSI's
exit

Invoke-Item $curpath\jre8.exe
Start-Sleep 5
move (Get-ChildItem $ENV:USERPROFILE\Appdata\LocalLow\Oracle\Java -Recurse -Filter *.msi).FullName $curpath\jre8.msi -Force
taskkill /t /f /im jre8.exe
RD $ENV:USERPROFILE\Appdata\LocalLow\Oracle -Force -Recurse

Invoke-Item $curpath\jre8-x64.exe
Start-Sleep 5
move (Get-ChildItem $ENV:USERPROFILE\Appdata\LocalLow\Oracle\Java -Recurse -Filter *.msi).FullName $curpath\jre8-x64.msi -Force
taskkill /t /f /im jre8-x64.exe
RD $ENV:USERPROFILE\Appdata\LocalLow\Oracle -Force -Recurse

del jre8.exe
del jre8-x64.exe
