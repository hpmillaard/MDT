clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -U '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
If ((gwmi win32_operatingsystem).OSLanguage -eq 1043){$Lang = "nl_NL"}Else{$Lang = "en_US"}
Start "$PSScriptRoot\AcroRdrDC_$Lang.exe" "/sPB /rs /msi EULA_ACCEPT=YES ENABLE_CHROMEEXT=0 DISABLE_BROWSER_INTEGRATION=1 ENABLE_OPTIMIZATION=YES ADD_THUMBNAILPREVIEW=0 DISABLEDESKTOPSHORTCUT=1 UPDATE_MODE=0 DISABLE_ARM_SERVICE_INSTALL=1" -Wait
Start "$PSScriptRoot\AcroRdrDCUpdate.msp" "/qb! /norestart" -Wait
reg import "$PSScriptRoot\adobe.reg"
sc.exe delete AdobeARMservice
schtasks /delete /TN "Adobe Acrobat Update Task" /F

If ($ENV:PROCESSOR_ARCHITECTURE -match 64){$Prog = ${ENV:ProgramFiles(x86)}}Else{$Prog = $ENV:ProgramFiles}
If (Test-Path "$PSScriptRoot\HideMenu.js"){copy "$PSScriptRoot\HideMenus.js" "$Prog\Adobe\Acrobat Reader DC\Reader\Javascripts\HideMenus.js" -Force}

change user /execute
Log "Finished installation"
exit 0