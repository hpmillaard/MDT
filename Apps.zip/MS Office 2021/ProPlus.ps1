clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSCommandPath).BaseName + " - " + (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -U '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
$c = "$ENV:TEMP\Config.xml"
ac $c "<Configuration>"
ac $c "  <Add OfficeClientEdition=""32"" Channel=""PerpetualVL2021"" SourcePath=""%TEMP%\O2021"" AllowCdnFallback=""TRUE"" ForceUpgrade=""TRUE"">"
ac $c "    <Product ID=""ProPlus2021Volume"" PIDKEY=""FXYTK-NJJ8C-GB6DW-3DYQT-6F7TH"">"
ac $c "      <Language ID=""MatchOS"" Fallback=""en-us"" />"
ac $c "      <Language ID=""nl-nl"" />"
#ac $c "      <ExcludeApp ID=""Access"" />"
#ac $c "      <ExcludeApp ID=""Excel"" />"
ac $c "      <ExcludeApp ID=""Lync"" />"
ac $c "      <ExcludeApp ID=""OneDrive"" />"
ac $c "      <ExcludeApp ID=""OneNote"" />"
#ac $c "      <ExcludeApp ID=""Outlook"" />"
#ac $c "      <ExcludeApp ID=""PowerPoint"" />"
ac $c "      <ExcludeApp ID=""Publisher"" />"
ac $c "      <ExcludeApp ID=""Teams"" />"
#ac $c "      <ExcludeApp ID=""Word"" />"
ac $c "    </Product>"
ac $c "    <Product ID=""ProofingTools"">"
ac $c "    	<Language ID=""nl-nl"" />"
ac $c "    </Product>"
ac $c "  </Add>"
ac $c "  <Property Name=""SharedComputerLicensing"" Value=""0"" />"
ac $c "  <Property Name=""PinIconsToTaskbar"" Value=""FALSE"" />"
ac $c "  <Property Name=""SCLCacheOverride"" Value=""0"" />"
ac $c "  <Updates Enabled=""TRUE"" />"
ac $c "  <RemoveMSI />"
ac $c "    <AppSettings>"
ac $c "      <User Key=""software\microsoft\office\16.0\common\toolbars"" Name=""customuiroaming"" Value=""1"" Type=""REG_DWORD"" App=""office16"" Id=""L_AllowRoamingQuickAccessToolBarRibbonCustomizations"" />"
ac $c "      <User Key=""software\microsoft\office\16.0\common\general"" Name=""shownfirstrunoptin"" Value=""1"" Type=""REG_DWORD"" App=""office16"" Id=""L_DisableOptinWizard"" />"
ac $c "      <User Key=""software\microsoft\office\16.0\common"" Name=""qmenable"" Value=""0"" Type=""REG_DWORD"" App=""office16"" Id=""L_EnableCustomerExperienceImprovementProgram"" />"
ac $c "      <User Key=""software\microsoft\office\16.0\common"" Name=""updatereliabilitydata"" Value=""1"" Type=""REG_DWORD"" App=""office16"" Id=""L_UpdateReliabilityPolicy"" />"
ac $c "      <User Key=""software\microsoft\office\16.0\firstrun"" Name=""disablemovie"" Value=""1"" Type=""REG_DWORD"" App=""office16"" Id=""L_DisableMovie"" />"
ac $c "      <User Key=""software\microsoft\office\16.0\outlook\message"" Name=""disablereadingpanecompose"" Value=""1"" Type=""REG_DWORD"" App=""outlk16"" Id=""L_DisableReadingPaneCompose"" />"
ac $c "    </AppSettings>"
ac $c "  <Display Level=""None"" AcceptEULA=""TRUE"" />"
ac $c "</Configuration>"

Start "$PSScriptRoot\setup.exe" "/download $c" -Wait
Start "$PSScriptRoot\setup.exe" "/configure $c" -Wait

gi $ENV:TEMP\O2021 | del -r
gi $ENV:TEMP\config.xml | del

change user /execute
Log "Finished installation"
exit 0