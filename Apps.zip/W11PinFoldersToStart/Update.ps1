clear
$host.ui.RawUI.WindowTitle = (gi $PSScriptRoot).Name
Start-BitsTransfer "https://download.sysinternals.com/files/PSTools.zip" "$PSScriptRoot\PSTools.zip"
Expand-Archive "$PSScriptRoot\PSTools.zip" -Destination $PSScriptRoot -Force
Sleep 1
del "$PSScriptRoot\PSTools.zip"
del "$PSScriptRoot\eula.txt"
del "$PSScriptRoot\pstools.chm"
del "$PSScriptRoot\psversion.txt"
del "$PSScriptRoot\*.exe" -Exclude psexec.exe