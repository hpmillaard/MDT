clear
$host.ui.RawUI.WindowTitle = (Get-Item $PSScriptRoot).Name
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Links = (curl -Uri https://www.7-zip.org/download.html -UseBasicParsing).Links | ? href -match msi
Start-BitsTransfer ('https://www.7-zip.org/' + ($Links | ? href -notmatch x64)[0].href) $PSScriptRoot\7Zip32.msi
Start-BitsTransfer ('https://www.7-zip.org/' + ($Links | ? href -match x64)[0].href) $PSScriptRoot\7Zip64.msi
