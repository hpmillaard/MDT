clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
$Links = (curl -Uri http://www.7-zip.org/download.html).Links | ? href -match msi
Start-BitsTransfer ('http://www.7-zip.org/' + ($Links | ? href -notmatch x64)[0].href) $curpath\7Zip32.msi
Start-BitsTransfer ('http://www.7-zip.org/' + ($Links | ? href -match x64)[0].href) $curpath\7Zip64.msi
