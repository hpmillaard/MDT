clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -U '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
winget install ScooterSoftware.BeyondCompare.5 -e --accept-source-agreements --scope machine

gci ([environment]::getfolderpath("desktop")) | ? name -match "Beyond Compare" | del -EA 0
gci ([environment]::getfolderpath("commondesktop")) | ? name -match "Beyond Compare" | del -EA 0
gci ([environment]::getfolderpath("commonprograms")) | ? name -match "Beyond Compare" | mi -Destination ([environment]::getfolderpath("commonprograms"))
gci ([environment]::getfolderpath("commonprograms")) -Directory | ? name -match "Beyond Compare" | del -recurse

rp "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" -Name BCClipboard -EA 0
spps -n BCClipboard -EA 0

$appFolder = (Join-Path $ENV:APPDATA "\Scooter Software\Beyond Compare 5")
If (!(Test-Path $AppFolder)){md $AppFolder}
If (Test-Path "$PSScriptRoot\BCCommands.xml"){copy "$PSScriptRoot\BCCommands.xml" $AppFolder}
If (Test-Path "$PSScriptRoot\BCPreferences.xml"){copy "$PSScriptRoot\BCPreferences.xml" $AppFolder}

change user /execute
Log "Finished installation"
exit 0