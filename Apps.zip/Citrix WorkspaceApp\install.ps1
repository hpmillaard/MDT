clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -U '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
Start "$PSScriptRoot\CitrixWorkspaceAppWeb.exe" "/EnableCEIP=false /silent /noreboot /includeSSON ENABLE_SSON=Yes ENABLE_KERBEROS=Yes" -Wait

change user /execute
Log "Finished installation"
exit 0