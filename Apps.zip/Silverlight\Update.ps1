clear
$host.ui.RawUI.WindowTitle = (Get-Item $PSScriptRoot).Name
Function Get-RedirectedUrl($URL){
	$request = [System.Net.WebRequest]::Create($URL)
	$request.AllowAutoRedirect=$false
	$response=$request.GetResponse()
	$response.GetResponseHeader("Location")
}
Start-BitsTransfer (Get-RedirectedUrl -URL 'http://go.microsoft.com/fwlink/?LinkId=229320') $PSScriptRoot\Silverlight32.exe
Start-BitsTransfer (Get-RedirectedUrl -URL 'http://go.microsoft.com/fwlink/?LinkId=229321') $PSScriptRoot\Silverlight64.exe
