clear

$host.ui.RawUI.WindowTitle = (Get-Item $PSScriptRoot).Name
Start-BitsTransfer 'https://www.dropbox.com/download?full=1&plat=win' $PSScriptRoot\Dropbox.exe
