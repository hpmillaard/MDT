clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
$UpdateFeed = New-Object System.Xml.XmlDocument
$UpdateFeed.Load("https://javadl-esd-secure.oracle.com/update/1.8.0/map-m-1.8.0.xml")
$latestUpdate = ($UpdateFeed.'java-update-map'.mapping | Where-Object {$_.url -notlike "*-cb.xml"} | Select-Object -Last 1).url
$UpdateFeed.Load($latestUpdate)
$URL = $UpdateFeed.'java-update'.information.url | Select-Object -First 1
Start-BitsTransfer ($URL -replace "au.exe", "i586.exe") $curpath\jre8.exe
Start-BitsTransfer ($URL -replace "au.exe", "x64.exe") $curpath\jre8-x64.exe

# Comment the next line to create MSI's
exit

Invoke-Item $curpath\jre8.exe
Start-Sleep 5
move (Get-ChildItem $ENV:USERPROFILE\Appdata\LocalLow\Oracle\Java -Recurse -Filter *.msi).FullName $curpath\jre8.msi -Force
taskkill /t /f /im jre8.exe
RD $ENV:USERPROFILE\Appdata\LocalLow\Oracle -Force -Recurse

Invoke-Item $curpath\jre8-x64.exe
Start-Sleep 5
move (Get-ChildItem $ENV:USERPROFILE\Appdata\LocalLow\Oracle\Java -Recurse -Filter *.msi).FullName $curpath\jre8-x64.msi -Force
taskkill /t /f /im jre8-x64.exe
RD $ENV:USERPROFILE\Appdata\LocalLow\Oracle -Force -Recurse

del jre8.exe
del jre8-x64.exe
