clear
$host.ui.RawUI.WindowTitle = (gi $PSScriptRoot).Name
Start-BitsTransfer "https://go.microsoft.com/fwlink/?linkid=860984" "$PSScriptRoot\OneDriveSetup.exe"
