clear
$host.ui.RawUI.WindowTitle = (gi $PSScriptRoot).Name
Start-BitsTransfer https://g.msn.com/1rewlive5skydrive/skydrivesetup $PSScriptRoot\OneDriveSetupWeb.exe
$CurrentVersion = (get-item $PSScriptRoot\OneDriveSetup.exe).VersionInfo.FileVersion
$WebVersion = (get-item $PSScriptRoot\OneDriveSetupWeb.exe).VersionInfo.FileVersion
$LocalVersion = (get-item $ENV:LOCALAPPDATA\Microsoft\OneDrive\Update\OneDriveSetup.exe).VersionInfo.FileVersion
If ($WebVersion -gt $CurrentVersion) {
	Write-Host "Webversion is newer, keep webversion"
	del $PSScriptRoot\OneDriveSetup.exe
	ren $PSScriptRoot\OneDriveSetupWeb.exe $PSScriptRoot\OneDriveSetup.exe
} Else {
	Write-Host "Webversion is older, remove webversion"
	del $PSScriptRoot\OneDriveSetupWeb.exe
}
If ($LocalVersion -gt $CurrentVersion) {
	Write-Host "Local version is newer, copy Local version"
	copy $ENV:LOCALAPPDATA\Microsoft\OneDrive\Update\OneDriveSetup.exe $PSScriptRoot\OneDriveSetup.exe -Force
}
