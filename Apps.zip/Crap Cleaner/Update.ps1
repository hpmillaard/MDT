clear
$host.ui.RawUI.WindowTitle = (gi $PSScriptRoot).Name

start taskkill "/f /im ccleaner.exe" -nnw
start taskkill "/f /im ccleaner64.exe" -nnw

Write-Host "Download CCleaner Portable" -F Green
Start-BitsTransfer ((iwr 'https://www.ccleaner.com/ccleaner/builds' -UseBasicParsing).Links | ? href -match ".zip").href "$PSScriptRoot\CCleaner.zip"
If ((gi "$PSScriptRoot\CCleaner.zip").length -gt 100kb){Expand-Archive "$PSScriptRoot\CCleaner.zip" -Destination "$PSScriptRoot" -Force} Else {del "$PSScriptRoot\CCleaner.zip"}

Write-Host "Download CCleaner Slim" -F Green
Start-BitsTransfer ((iwr 'https://www.ccleaner.com/ccleaner/builds' -UseBasicParsing).Links | ? href -match "slim").href "$PSScriptRoot\ccsetup_slim_new.exe"
If ((gi "$PSScriptRoot\ccsetup_slim_new.exe").length -gt 100kb){del "$PSScriptRoot\ccsetup_slim.exe";ren "$PSScriptRoot\ccsetup_slim_new.exe" "$PSScriptRoot\ccsetup_slim.exe" -Force} Else {del "$PSScriptRoot\ccsetup_slim_new.exe"}

rd "$PSScriptRoot\data" -Recurse -Force -ErrorAction SilentlyContinue
rd "$PSScriptRoot\log" -Recurse -Force -ErrorAction SilentlyContinue
rd "$PSScriptRoot\lang" -Recurse -Force -ErrorAction SilentlyContinue
rd "$PSScriptRoot\setup" -Recurse -Force -ErrorAction SilentlyContinue
rd "$PSScriptRoot\temp_ccupdate" -Recurse -Force -ErrorAction SilentlyContinue
rd "$PSScriptRoot\x86" -Recurse -Force -ErrorAction SilentlyContinue
rd "$PSScriptRoot\x64" -Recurse -Force -ErrorAction SilentlyContinue
del "$PSScriptRoot\License.txt" -ErrorAction SilentlyContinue
del "$PSScriptRoot\portable.dat" -ErrorAction SilentlyContinue
del "$PSScriptRoot\CCleaner.zip" -ErrorAction SilentlyContinue
del "$PSScriptRoot\CCleaner*.dll" -ErrorAction SilentlyContinue
del "$PSScriptRoot\gcapi*.dll" -ErrorAction SilentlyContinue
del "$PSScriptRoot\*conflict*" -ErrorAction SilentlyContinue