clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name

Start-BitsTransfer ((curl 'https://www.ccleaner.com/ccleaner/download/portable').Links | ? href -match ".zip").href $curpath\CCleaner.zip
If ((Get-Item $curpath\CCleaner.zip).length -gt 100kb) {Expand-Archive $curpath\CCleaner.zip -Destination $curpath -Force} Else {del $curpath\CCleaner.zip}

rd $curpath\lang -Recurse -Force
del $curpath\License.txt
del $curpath\portable.dat
del $curpath\CCleaner.zip
