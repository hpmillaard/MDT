clear
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start powershell "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}
$title = (gi $PSScriptRoot).Name
$host.ui.RawUI.WindowTitle = "Installing $title"

Function Log($Content){Write-Host -f Green $content;ac $ENV:WINDIR\AppInstall.txt "$(Get-Date -UF '%a %d-%m-%G %X') $title - $content"}
Log "Installation started"
change user /install

#Install commands
Start powershell "-executionpolicy bypass -file ""$PSScriptRoot\ProPlus.ps1""" -Wait
Start powershell "-executionpolicy bypass -file ""$PSScriptRoot\Visio.ps1""" -Wait
#Start powershell "-executionpolicy bypass -file ""$PSScriptRoot\Project.ps1""" -Wait

gi $ENV:TEMP\O2024 | del -r
gi $ENV:TEMP\config.xml | del

change user /execute
Log "Finished installation"
exit 0