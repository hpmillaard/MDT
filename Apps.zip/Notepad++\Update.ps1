clear
$host.ui.RawUI.WindowTitle = (gi $PSScriptRoot).Name
Start-BitsTransfer (((curl https://api.github.com/repos/notepad-plus-plus/notepad-plus-plus/releases -useb).Content | ConvertFrom-Json).assets | ? {$_.name -match "installer.exe" -and $_.name -notmatch "sig"})[0].browser_download_url $PSScriptRoot\npp-x32.exe
Start-BitsTransfer (((curl https://api.github.com/repos/notepad-plus-plus/notepad-plus-plus/releases -useb).Content | ConvertFrom-Json).assets | ? {$_.name -match "installer.x64.exe" -and $_.name -notmatch "sig"})[0].browser_download_url $PSScriptRoot\npp-x64.exe
