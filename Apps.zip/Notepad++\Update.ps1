clear
$host.ui.RawUI.WindowTitle = (Get-Item $PSScriptRoot).Name
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Links = (curl (-Join('https://notepad-plus-plus.org', ((curl "https://notepad-plus-plus.org/download").Links | ? outerText -match "current").href))).Links
curl ($Links | ? href -match "installer.exe")[0].href -OutFile $PSScriptRoot\npp-x32.exe
curl ($Links | ? href -match "installer.x64.exe")[0].href -OutFile $PSScriptRoot\npp-x64.exe
