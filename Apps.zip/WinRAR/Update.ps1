clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
$Links = (curl "http://www.rarlabs.com/download.htm").Links
Start-BitsTransfer ('http://www.rarlabs.com' + ($Links | ? innerText -match "WinRAR x86")[0].href) $curpath\WinRAR.exe
Start-BitsTransfer ('http://www.rarlabs.com' + ($Links | ? innerText -match "WinRAR x64")[0].href) $curpath\WinRAR-x64.exe
Start-BitsTransfer ('http://www.rarlabs.com' + ($Links | ? innerText -match "Dutch \(32")[0].href) $curpath\WinRAR-nl.exe
Start-BitsTransfer ('http://www.rarlabs.com' + ($Links | ? innerText -match "Dutch \(64")[0].href) $curpath\WinRAR-x64-nl.exe
