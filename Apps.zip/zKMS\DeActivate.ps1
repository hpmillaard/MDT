If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit}

#DeActivate Windows
cscript $ENV:WINDIR\System32\slmgr.vbs /ckms
cscript $ENV:WINDIR\System32\slmgr.vbs /ato

#Activate Office
ForEach ($n in (14..16)) {If ((Test-Path "${ENV:ProgramFiles(x86)}\Microsoft Office\Office$n\ospp.vbs") -eq $True) {$V = $n; $x86 = $True}}
ForEach ($n in (14..16)) {If ((Test-Path "$ENV:ProgramFiles\Microsoft Office\Office$n\ospp.vbs") -eq $True) {$V = $n; $x64 = $True}}
If ($x86) {
	cscript "${ENV:ProgramFiles(x86)}\Microsoft Office\Office$V\ospp.vbs" /remhst
	cscript "${ENV:ProgramFiles(x86)}\Microsoft Office\Office$V\ospp.vbs" /act
	clear
	cscript "${ENV:ProgramFiles(x86)}\Microsoft Office\Office$V\ospp.vbs" /dstatus
}
If ($x64) {
	cscript "$ENV:ProgramFiles\Microsoft Office\Office$V\ospp.vbs" /remhst
	cscript "$ENV:ProgramFiles\Microsoft Office\Office$V\ospp.vbs" /act
	clear
	cscript "$ENV:ProgramFiles\Microsoft Office\Office$V\ospp.vbs" /dstatus
}
cscript $ENV:WINDIR\System32\slmgr.vbs /dlv
