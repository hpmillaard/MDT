clear
$host.ui.RawUI.WindowTitle = (gi $PSScriptRoot).Name
Start-BitsTransfer https://the.earth.li/~sgtatham/putty/latest/w32/putty.exe $PSScriptRoot\putty.exe
Start-BitsTransfer https://the.earth.li/~sgtatham/putty/latest/w32/pscp.exe $PSScriptRoot\pscp.exe
