clear
$curpath = Split-Path -Parent $PSCommandPath
$host.ui.RawUI.WindowTitle = (Get-Item $curpath).Name
Start-BitsTransfer https://the.earth.li/~sgtatham/putty/latest/w32/putty.exe $curpath\putty.exe
Start-BitsTransfer https://the.earth.li/~sgtatham/putty/latest/w32/pscp.exe $curpath\pscp.exe
